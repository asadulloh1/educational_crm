import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from 'components/AppIcon';
import AuthenticationNav from 'components/ui/AuthenticationNav';

const UserRegistrationScreen = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedRole, setSelectedRole] = useState('');
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: '',
    // Role-specific fields
    department: '',
    subjectSpecialization: '',
    gradeLevel: '',
    studentId: '',
    studentConnectionCode: '',
    institutionCode: '',
    agreeToTerms: false,
    agreeToPrivacy: false
  });
  const [errors, setErrors] = useState({});
  const [passwordStrength, setPasswordStrength] = useState(0);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const roles = [
    {
      id: 'teacher',
      name: 'Teacher',
      description: 'Educators and faculty members',
      icon: 'GraduationCap',
      color: 'bg-blue-50 border-blue-200 text-blue-700'
    },
    {
      id: 'student',
      name: 'Student',
      description: 'Learners and course participants',
      icon: 'BookOpen',
      color: 'bg-green-50 border-green-200 text-green-700'
    },
    {
      id: 'parent',
      name: 'Parent',
      description: 'Parents and guardians',
      icon: 'Heart',
      color: 'bg-purple-50 border-purple-200 text-purple-700'
    }
  ];

  const departments = [
    'Mathematics', 'Science', 'English', 'History', 'Art', 'Physical Education',
    'Music', 'Computer Science', 'Foreign Languages', 'Special Education'
  ];

  const subjects = [
    'Algebra', 'Geometry', 'Biology', 'Chemistry', 'Physics', 'Literature',
    'Grammar', 'World History', 'American History', 'Drawing', 'Painting'
  ];

  const gradeLevels = [
    'Pre-K', 'Kindergarten', '1st Grade', '2nd Grade', '3rd Grade', '4th Grade',
    '5th Grade', '6th Grade', '7th Grade', '8th Grade', '9th Grade', '10th Grade',
    '11th Grade', '12th Grade', 'College Freshman', 'College Sophomore'
  ];

  const calculatePasswordStrength = (password) => {
    let strength = 0;
    if (password.length >= 8) strength += 25;
    if (/[a-z]/.test(password)) strength += 25;
    if (/[A-Z]/.test(password)) strength += 25;
    if (/[0-9]/.test(password) && /[^A-Za-z0-9]/.test(password)) strength += 25;
    return strength;
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    if (field === 'password') {
      setPasswordStrength(calculatePasswordStrength(value));
    }
    
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateStep = (step) => {
    const newErrors = {};
    
    if (step === 1) {
      if (!selectedRole) {
        newErrors.role = 'Please select your role';
      }
    }
    
    if (step === 2) {
      if (!formData.fullName.trim()) {
        newErrors.fullName = 'Full name is required';
      }
      
      if (!formData.email.trim()) {
        newErrors.email = 'Email is required';
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
        newErrors.email = 'Please enter a valid email address';
      }
      
      if (!formData.password) {
        newErrors.password = 'Password is required';
      } else if (formData.password.length < 8) {
        newErrors.password = 'Password must be at least 8 characters';
      }
      
      if (!formData.confirmPassword) {
        newErrors.confirmPassword = 'Please confirm your password';
      } else if (formData.password !== formData.confirmPassword) {
        newErrors.confirmPassword = 'Passwords do not match';
      }
    }
    
    if (step === 3) {
      if (selectedRole === 'teacher') {
        if (!formData.department) {
          newErrors.department = 'Department is required';
        }
        if (!formData.subjectSpecialization) {
          newErrors.subjectSpecialization = 'Subject specialization is required';
        }
      }
      
      if (selectedRole === 'student') {
        if (!formData.gradeLevel) {
          newErrors.gradeLevel = 'Grade level is required';
        }
        if (!formData.studentId.trim()) {
          newErrors.studentId = 'Student ID is required';
        }
      }
      
      if (selectedRole === 'parent') {
        if (!formData.studentConnectionCode.trim()) {
          newErrors.studentConnectionCode = 'Student connection code is required';
        }
      }
      
      if (!formData.institutionCode.trim()) {
        newErrors.institutionCode = 'Institution code is required';
      }
    }
    
    if (step === 4) {
      if (!formData.agreeToTerms) {
        newErrors.agreeToTerms = 'You must agree to the terms of service';
      }
      if (!formData.agreeToPrivacy) {
        newErrors.agreeToPrivacy = 'You must agree to the privacy policy';
      }
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handlePrevious = () => {
    setCurrentStep(prev => prev - 1);
  };

  const handleSubmit = async () => {
    if (!validateStep(4)) return;
    
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      // Navigate to appropriate dashboard based on role
      const dashboardRoutes = {
        teacher: '/teacher-dashboard',
        student: '/student-dashboard',
        parent: '/parent-dashboard'
      };
      navigate(dashboardRoutes[selectedRole]);
    }, 2000);
  };

  const getProgressPercentage = () => {
    return (currentStep / 4) * 100;
  };

  const getPasswordStrengthColor = () => {
    if (passwordStrength < 25) return 'bg-red-500';
    if (passwordStrength < 50) return 'bg-orange-500';
    if (passwordStrength < 75) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const getPasswordStrengthText = () => {
    if (passwordStrength < 25) return 'Weak';
    if (passwordStrength < 50) return 'Fair';
    if (passwordStrength < 75) return 'Good';
    return 'Strong';
  };

  return (
    <div className="min-h-screen bg-background">
      <AuthenticationNav />
      
      <div className="pt-32 pb-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md mx-auto">
          {/* Progress Bar */}
          <div className="mb-8">
            <div className="flex justify-between text-sm font-medium text-text-secondary mb-2">
              <span>Step {currentStep} of 4</span>
              <span>{Math.round(getProgressPercentage())}% Complete</span>
            </div>
            <div className="w-full bg-secondary-200 rounded-full h-2">
              <div 
                className="bg-primary h-2 rounded-full transition-all duration-300"
                style={{ width: `${getProgressPercentage()}%` }}
              ></div>
            </div>
          </div>

          {/* Registration Form */}
          <div className="bg-surface rounded-lg shadow-card p-8">
            <div className="text-center mb-8">
              <h1 className="text-2xl font-heading font-bold text-text-primary mb-2">
                Create Your Account
              </h1>
              <p className="text-text-secondary">
                Join our educational community today
              </p>
            </div>

            {/* Step 1: Role Selection */}
            {currentStep === 1 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-lg font-heading font-semibold text-text-primary mb-4">
                    Select Your Role
                  </h2>
                  <div className="space-y-3">
                    {roles.map((role) => (
                      <button
                        key={role.id}
                        onClick={() => setSelectedRole(role.id)}
                        className={`w-full p-4 rounded-lg border-2 transition-micro text-left ${
                          selectedRole === role.id
                            ? 'border-primary bg-primary-50' :'border-secondary-200 hover:border-secondary-300'
                        }`}
                      >
                        <div className="flex items-center space-x-3">
                          <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${role.color}`}>
                            <Icon name={role.icon} size={24} />
                          </div>
                          <div>
                            <h3 className="font-medium text-text-primary">{role.name}</h3>
                            <p className="text-sm text-text-secondary">{role.description}</p>
                          </div>
                          {selectedRole === role.id && (
                            <Icon name="CheckCircle" size={20} className="text-primary ml-auto" />
                          )}
                        </div>
                      </button>
                    ))}
                  </div>
                  {errors.role && (
                    <p className="text-error text-sm mt-2">{errors.role}</p>
                  )}
                </div>
              </div>
            )}

            {/* Step 2: Basic Information */}
            {currentStep === 2 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-lg font-heading font-semibold text-text-primary mb-4">
                    Basic Information
                  </h2>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-text-primary mb-2">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        value={formData.fullName}
                        onChange={(e) => handleInputChange('fullName', e.target.value)}
                        className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 ${
                          errors.fullName ? 'border-error' : 'border-secondary-300'
                        }`}
                        placeholder="Enter your full name"
                      />
                      {errors.fullName && (
                        <p className="text-error text-sm mt-1">{errors.fullName}</p>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-text-primary mb-2">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 ${
                          errors.email ? 'border-error' : 'border-secondary-300'
                        }`}
                        placeholder="Enter your email address"
                      />
                      {errors.email && (
                        <p className="text-error text-sm mt-1">{errors.email}</p>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-text-primary mb-2">
                        Password *
                      </label>
                      <div className="relative">
                        <input
                          type={showPassword ? 'text' : 'password'}
                          value={formData.password}
                          onChange={(e) => handleInputChange('password', e.target.value)}
                          className={`w-full px-3 py-2 pr-10 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 ${
                            errors.password ? 'border-error' : 'border-secondary-300'
                          }`}
                          placeholder="Create a strong password"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 transform -translate-y-1/2 text-text-secondary hover:text-text-primary"
                        >
                          <Icon name={showPassword ? 'EyeOff' : 'Eye'} size={18} />
                        </button>
                      </div>
                      {formData.password && (
                        <div className="mt-2">
                          <div className="flex items-center space-x-2">
                            <div className="flex-1 bg-secondary-200 rounded-full h-1">
                              <div 
                                className={`h-1 rounded-full transition-all duration-300 ${getPasswordStrengthColor()}`}
                                style={{ width: `${passwordStrength}%` }}
                              ></div>
                            </div>
                            <span className="text-xs text-text-secondary">
                              {getPasswordStrengthText()}
                            </span>
                          </div>
                        </div>
                      )}
                      {errors.password && (
                        <p className="text-error text-sm mt-1">{errors.password}</p>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-text-primary mb-2">
                        Confirm Password *
                      </label>
                      <div className="relative">
                        <input
                          type={showConfirmPassword ? 'text' : 'password'}
                          value={formData.confirmPassword}
                          onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                          className={`w-full px-3 py-2 pr-10 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 ${
                            errors.confirmPassword ? 'border-error' : 'border-secondary-300'
                          }`}
                          placeholder="Confirm your password"
                        />
                        <button
                          type="button"
                          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                          className="absolute right-3 top-1/2 transform -translate-y-1/2 text-text-secondary hover:text-text-primary"
                        >
                          <Icon name={showConfirmPassword ? 'EyeOff' : 'Eye'} size={18} />
                        </button>
                      </div>
                      {errors.confirmPassword && (
                        <p className="text-error text-sm mt-1">{errors.confirmPassword}</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Step 3: Role-Specific Information */}
            {currentStep === 3 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-lg font-heading font-semibold text-text-primary mb-4">
                    {selectedRole === 'teacher' && 'Teaching Information'}
                    {selectedRole === 'student' && 'Student Information'}
                    {selectedRole === 'parent' && 'Parent Information'}
                  </h2>
                  
                  <div className="space-y-4">
                    {selectedRole === 'teacher' && (
                      <>
                        <div>
                          <label className="block text-sm font-medium text-text-primary mb-2">
                            Department *
                          </label>
                          <select
                            value={formData.department}
                            onChange={(e) => handleInputChange('department', e.target.value)}
                            className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 ${
                              errors.department ? 'border-error' : 'border-secondary-300'
                            }`}
                          >
                            <option value="">Select your department</option>
                            {departments.map((dept) => (
                              <option key={dept} value={dept}>{dept}</option>
                            ))}
                          </select>
                          {errors.department && (
                            <p className="text-error text-sm mt-1">{errors.department}</p>
                          )}
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-text-primary mb-2">
                            Subject Specialization *
                          </label>
                          <select
                            value={formData.subjectSpecialization}
                            onChange={(e) => handleInputChange('subjectSpecialization', e.target.value)}
                            className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 ${
                              errors.subjectSpecialization ? 'border-error' : 'border-secondary-300'
                            }`}
                          >
                            <option value="">Select your specialization</option>
                            {subjects.map((subject) => (
                              <option key={subject} value={subject}>{subject}</option>
                            ))}
                          </select>
                          {errors.subjectSpecialization && (
                            <p className="text-error text-sm mt-1">{errors.subjectSpecialization}</p>
                          )}
                        </div>
                      </>
                    )}

                    {selectedRole === 'student' && (
                      <>
                        <div>
                          <label className="block text-sm font-medium text-text-primary mb-2">
                            Grade Level *
                          </label>
                          <select
                            value={formData.gradeLevel}
                            onChange={(e) => handleInputChange('gradeLevel', e.target.value)}
                            className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 ${
                              errors.gradeLevel ? 'border-error' : 'border-secondary-300'
                            }`}
                          >
                            <option value="">Select your grade level</option>
                            {gradeLevels.map((grade) => (
                              <option key={grade} value={grade}>{grade}</option>
                            ))}
                          </select>
                          {errors.gradeLevel && (
                            <p className="text-error text-sm mt-1">{errors.gradeLevel}</p>
                          )}
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-text-primary mb-2">
                            Student ID *
                          </label>
                          <input
                            type="text"
                            value={formData.studentId}
                            onChange={(e) => handleInputChange('studentId', e.target.value)}
                            className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 ${
                              errors.studentId ? 'border-error' : 'border-secondary-300'
                            }`}
                            placeholder="Enter your student ID"
                          />
                          {errors.studentId && (
                            <p className="text-error text-sm mt-1">{errors.studentId}</p>
                          )}
                        </div>
                      </>
                    )}

                    {selectedRole === 'parent' && (
                      <div>
                        <label className="block text-sm font-medium text-text-primary mb-2">
                          Student Connection Code *
                        </label>
                        <input
                          type="text"
                          value={formData.studentConnectionCode}
                          onChange={(e) => handleInputChange('studentConnectionCode', e.target.value)}
                          className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 ${
                            errors.studentConnectionCode ? 'border-error' : 'border-secondary-300'
                          }`}
                          placeholder="Enter student connection code"
                        />
                        <p className="text-xs text-text-secondary mt-1">
                          Get this code from your child's teacher or school administrator
                        </p>
                        {errors.studentConnectionCode && (
                          <p className="text-error text-sm mt-1">{errors.studentConnectionCode}</p>
                        )}
                      </div>
                    )}

                    <div>
                      <label className="block text-sm font-medium text-text-primary mb-2">
                        Institution Code *
                      </label>
                      <input
                        type="text"
                        value={formData.institutionCode}
                        onChange={(e) => handleInputChange('institutionCode', e.target.value)}
                        className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 ${
                          errors.institutionCode ? 'border-error' : 'border-secondary-300'
                        }`}
                        placeholder="Enter institution code"
                      />
                      <p className="text-xs text-text-secondary mt-1">
                        Contact your school administrator for this code
                      </p>
                      {errors.institutionCode && (
                        <p className="text-error text-sm mt-1">{errors.institutionCode}</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Step 4: Terms and Verification */}
            {currentStep === 4 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-lg font-heading font-semibold text-text-primary mb-4">
                    Terms & Verification
                  </h2>
                  
                  <div className="space-y-4">
                    <div className="bg-secondary-50 rounded-lg p-4">
                      <h3 className="font-medium text-text-primary mb-2">Account Summary</h3>
                      <div className="space-y-2 text-sm text-text-secondary">
                        <p><span className="font-medium">Name:</span> {formData.fullName}</p>
                        <p><span className="font-medium">Email:</span> {formData.email}</p>
                        <p><span className="font-medium">Role:</span> {roles.find(r => r.id === selectedRole)?.name}</p>
                        {selectedRole === 'teacher' && (
                          <>
                            <p><span className="font-medium">Department:</span> {formData.department}</p>
                            <p><span className="font-medium">Subject:</span> {formData.subjectSpecialization}</p>
                          </>
                        )}
                        {selectedRole === 'student' && (
                          <>
                            <p><span className="font-medium">Grade:</span> {formData.gradeLevel}</p>
                            <p><span className="font-medium">Student ID:</span> {formData.studentId}</p>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="space-y-3">
                      <label className="flex items-start space-x-3">
                        <input
                          type="checkbox"
                          checked={formData.agreeToTerms}
                          onChange={(e) => handleInputChange('agreeToTerms', e.target.checked)}
                          className="mt-1 w-4 h-4 text-primary border-secondary-300 rounded focus:ring-primary-500"
                        />
                        <span className="text-sm text-text-secondary">
                          I agree to the{' '}
                          <button className="text-primary hover:underline">Terms of Service</button>
                          {' '}and understand my responsibilities as a {selectedRole} user.
                        </span>
                      </label>
                      {errors.agreeToTerms && (
                        <p className="text-error text-sm ml-7">{errors.agreeToTerms}</p>
                      )}

                      <label className="flex items-start space-x-3">
                        <input
                          type="checkbox"
                          checked={formData.agreeToPrivacy}
                          onChange={(e) => handleInputChange('agreeToPrivacy', e.target.checked)}
                          className="mt-1 w-4 h-4 text-primary border-secondary-300 rounded focus:ring-primary-500"
                        />
                        <span className="text-sm text-text-secondary">
                          I acknowledge that I have read and agree to the{' '}
                          <button className="text-primary hover:underline">Privacy Policy</button>
                          {' '}regarding the collection and use of my personal information.
                        </span>
                      </label>
                      {errors.agreeToPrivacy && (
                        <p className="text-error text-sm ml-7">{errors.agreeToPrivacy}</p>
                      )}
                    </div>

                    <div className="bg-accent-50 rounded-lg p-4">
                      <div className="flex items-start space-x-3">
                        <Icon name="Info" size={20} className="text-accent-600 mt-0.5" />
                        <div>
                          <h4 className="font-medium text-accent-800 mb-1">Email Verification Required</h4>
                          <p className="text-sm text-accent-700">
                            After registration, you'll receive a verification email. Please check your inbox and follow the instructions to activate your account.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between pt-6 border-t border-border">
              <button
                onClick={handlePrevious}
                disabled={currentStep === 1}
                className={`px-6 py-2 rounded-lg font-medium transition-micro flex items-center space-x-2 ${
                  currentStep === 1
                    ? 'bg-secondary-100 text-text-secondary cursor-not-allowed' :'bg-secondary-100 hover:bg-secondary-200 text-text-primary'
                }`}
              >
                <Icon name="ArrowLeft" size={16} />
                <span>Previous</span>
              </button>

              {currentStep < 4 ? (
                <button
                  onClick={handleNext}
                  className="px-6 py-2 bg-primary hover:bg-primary-700 text-white rounded-lg font-medium transition-micro flex items-center space-x-2"
                >
                  <span>Next</span>
                  <Icon name="ArrowRight" size={16} />
                </button>
              ) : (
                <button
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                  className="px-6 py-2 bg-primary hover:bg-primary-700 disabled:bg-secondary-300 text-white rounded-lg font-medium transition-micro flex items-center space-x-2"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Creating Account...</span>
                    </>
                  ) : (
                    <>
                      <Icon name="UserPlus" size={16} />
                      <span>Create Account</span>
                    </>
                  )}
                </button>
              )}
            </div>

            {/* Login Link */}
            <div className="text-center pt-6 border-t border-border mt-6">
              <p className="text-sm text-text-secondary">
                Already have an account?{' '}
                <button
                  onClick={() => navigate('/login-screen')}
                  className="text-primary hover:text-primary-700 font-medium"
                >
                  Sign in here
                </button>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserRegistrationScreen;