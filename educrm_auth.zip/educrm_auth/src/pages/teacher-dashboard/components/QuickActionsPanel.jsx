import React from 'react';
import Icon from 'components/AppIcon';

const QuickActionsPanel = ({ onAction }) => {
  const quickActions = [
    {
      id: 'create-assignment',
      title: 'Create Assignment',
      description: 'Design and assign new homework or projects',
      icon: 'FilePlus',
      color: 'bg-primary',
      hoverColor: 'hover:bg-primary-700'
    },
    {
      id: 'send-announcement',
      title: 'Send Announcement',
      description: 'Notify students and parents about important updates',
      icon: 'Megaphone',
      color: 'bg-accent',
      hoverColor: 'hover:bg-accent-600'
    },
    {
      id: 'schedule-meeting',
      title: 'Schedule Meeting',
      description: 'Book parent conferences or student meetings',
      icon: 'Calendar',
      color: 'bg-success',
      hoverColor: 'hover:bg-success-600'
    },
    {
      id: 'grade-submissions',
      title: 'Grade Submissions',
      description: 'Review and grade pending student work',
      icon: 'Award',
      color: 'bg-warning',
      hoverColor: 'hover:bg-warning-600'
    }
  ];

  const handleActionClick = (actionId) => {
    onAction(actionId);
  };

  return (
    <div className="bg-surface rounded-xl shadow-card border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-heading font-semibold text-text-primary">
          Quick Actions
        </h2>
        <div className="flex items-center space-x-2 text-text-secondary text-sm">
          <Icon name="Zap" size={16} />
          <span>Streamline your workflow</span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {quickActions.map((action) => (
          <button
            key={action.id}
            onClick={() => handleActionClick(action.id)}
            className="group relative bg-gradient-to-br from-secondary-50 to-secondary-100 hover:from-secondary-100 hover:to-secondary-200 rounded-xl p-4 text-left transition-all duration-300 hover:shadow-floating border border-border hover:border-secondary-300"
          >
            <div className="flex items-start space-x-3">
              <div className={`w-10 h-10 ${action.color} ${action.hoverColor} rounded-lg flex items-center justify-center transition-colors group-hover:scale-110 transform duration-200`}>
                <Icon name={action.icon} size={20} color="white" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-medium text-text-primary mb-1 group-hover:text-primary transition-colors">
                  {action.title}
                </h3>
                <p className="text-xs text-text-secondary leading-relaxed">
                  {action.description}
                </p>
              </div>
            </div>
            
            {/* Hover Arrow */}
            <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
              <Icon name="ArrowUpRight" size={16} className="text-text-secondary" />
            </div>
          </button>
        ))}
      </div>

      {/* Additional Quick Links */}
      <div className="mt-6 pt-6 border-t border-border">
        <div className="flex flex-wrap items-center gap-4">
          <button className="flex items-center space-x-2 text-text-secondary hover:text-primary text-sm transition-colors">
            <Icon name="BookOpen" size={16} />
            <span>Lesson Plans</span>
          </button>
          <button className="flex items-center space-x-2 text-text-secondary hover:text-primary text-sm transition-colors">
            <Icon name="BarChart3" size={16} />
            <span>Analytics</span>
          </button>
          <button className="flex items-center space-x-2 text-text-secondary hover:text-primary text-sm transition-colors">
            <Icon name="Settings" size={16} />
            <span>Class Settings</span>
          </button>
          <button className="flex items-center space-x-2 text-text-secondary hover:text-primary text-sm transition-colors">
            <Icon name="HelpCircle" size={16} />
            <span>Help Center</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default QuickActionsPanel;