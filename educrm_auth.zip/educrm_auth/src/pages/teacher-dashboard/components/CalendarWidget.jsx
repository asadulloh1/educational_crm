import React, { useState } from 'react';
import Icon from 'components/AppIcon';

const CalendarWidget = ({ events }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const daysOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  const getDaysInMonth = (date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days = [];
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }
    
    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(new Date(year, month, day));
    }
    
    return days;
  };

  const navigateMonth = (direction) => {
    const newDate = new Date(currentDate);
    newDate.setMonth(currentDate.getMonth() + direction);
    setCurrentDate(newDate);
  };

  const isToday = (date) => {
    if (!date) return false;
    const today = new Date();
    return date.toDateString() === today.toDateString();
  };

  const isSelected = (date) => {
    if (!date) return false;
    return date.toDateString() === selectedDate.toDateString();
  };

  const hasEvent = (date) => {
    if (!date) return false;
    return events.some(event => {
      const eventDate = new Date(event.date);
      return eventDate.toDateString() === date.toDateString();
    });
  };

  const getEventsForDate = (date) => {
    if (!date) return [];
    return events.filter(event => {
      const eventDate = new Date(event.date);
      return eventDate.toDateString() === date.toDateString();
    });
  };

  const getEventTypeColor = (type) => {
    switch (type) {
      case 'meeting':
        return 'bg-primary text-white';
      case 'exam':
        return 'bg-error text-white';
      case 'training':
        return 'bg-success text-white';
      default:
        return 'bg-accent text-white';
    }
  };

  const getEventTypeIcon = (type) => {
    switch (type) {
      case 'meeting':
        return 'Users';
      case 'exam':
        return 'FileText';
      case 'training':
        return 'BookOpen';
      default:
        return 'Calendar';
    }
  };

  const upcomingEvents = events
    .filter(event => new Date(event.date) >= new Date())
    .sort((a, b) => new Date(a.date) - new Date(b.date))
    .slice(0, 3);

  return (
    <div className="bg-surface rounded-xl shadow-card border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-heading font-semibold text-text-primary">
          Calendar
        </h3>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => navigateMonth(-1)}
            className="p-1 text-text-secondary hover:text-primary hover:bg-secondary-50 rounded transition-micro"
          >
            <Icon name="ChevronLeft" size={16} />
          </button>
          <button
            onClick={() => navigateMonth(1)}
            className="p-1 text-text-secondary hover:text-primary hover:bg-secondary-50 rounded transition-micro"
          >
            <Icon name="ChevronRight" size={16} />
          </button>
        </div>
      </div>

      {/* Calendar Header */}
      <div className="text-center mb-4">
        <h4 className="text-lg font-medium text-text-primary">
          {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
        </h4>
      </div>

      {/* Days of Week */}
      <div className="grid grid-cols-7 gap-1 mb-2">
        {daysOfWeek.map((day) => (
          <div key={day} className="text-center text-xs font-medium text-text-secondary py-2">
            {day}
          </div>
        ))}
      </div>

      {/* Calendar Days */}
      <div className="grid grid-cols-7 gap-1 mb-6">
        {getDaysInMonth(currentDate).map((date, index) => (
          <button
            key={index}
            onClick={() => date && setSelectedDate(date)}
            className={`relative h-8 text-sm rounded transition-micro ${
              !date
                ? 'cursor-default'
                : isSelected(date)
                ? 'bg-primary text-white'
                : isToday(date)
                ? 'bg-primary-100 text-primary font-medium' :'text-text-primary hover:bg-secondary-50'
            }`}
            disabled={!date}
          >
            {date && (
              <>
                <span>{date.getDate()}</span>
                {hasEvent(date) && (
                  <div className="absolute bottom-0.5 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-accent rounded-full"></div>
                )}
              </>
            )}
          </button>
        ))}
      </div>

      {/* Upcoming Events */}
      <div>
        <h4 className="text-sm font-medium text-text-primary mb-3 flex items-center space-x-2">
          <Icon name="Clock" size={14} />
          <span>Upcoming Events</span>
        </h4>
        <div className="space-y-2">
          {upcomingEvents.length > 0 ? (
            upcomingEvents.map((event) => (
              <div
                key={event.id}
                className="flex items-start space-x-3 p-2 rounded-lg hover:bg-secondary-50 transition-micro"
              >
                <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${getEventTypeColor(event.type)}`}>
                  <Icon name={getEventTypeIcon(event.type)} size={12} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-text-primary truncate">
                    {event.title}
                  </p>
                  <p className="text-xs text-text-secondary">
                    {new Date(event.date).toLocaleDateString()} at {event.time}
                  </p>
                </div>
              </div>
            ))
          ) : (
            <p className="text-sm text-text-secondary text-center py-4">
              No upcoming events
            </p>
          )}
        </div>
      </div>

      {/* Selected Date Events */}
      {getEventsForDate(selectedDate).length > 0 && (
        <div className="mt-4 pt-4 border-t border-border">
          <h4 className="text-sm font-medium text-text-primary mb-2">
            {selectedDate.toLocaleDateString()} Events
          </h4>
          <div className="space-y-1">
            {getEventsForDate(selectedDate).map((event) => (
              <div key={event.id} className="text-xs text-text-secondary">
                <span className="font-medium">{event.time}</span> - {event.title}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default CalendarWidget;