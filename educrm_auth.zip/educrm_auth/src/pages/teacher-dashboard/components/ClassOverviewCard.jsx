import React from 'react';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const ClassOverviewCard = ({ classData, onSelect, isSelected }) => {
  const {
    name,
    subject,
    grade,
    students,
    room,
    schedule,
    nextClass,
    recentAssignment,
    pendingSubmissions,
    averageGrade,
    color,
    image
  } = classData;

  const getGradeColor = (grade) => {
    if (grade >= 90) return 'text-success-600';
    if (grade >= 80) return 'text-warning-600';
    return 'text-error-600';
  };

  const handleCardClick = () => {
    onSelect(classData);
  };

  return (
    <div 
      className={`bg-surface rounded-xl shadow-card border transition-all duration-300 cursor-pointer hover:shadow-floating ${
        isSelected ? 'border-primary ring-2 ring-primary ring-opacity-20' : 'border-border hover:border-primary-200'
      }`}
      onClick={handleCardClick}
    >
      {/* Class Image Header */}
      <div className="relative h-32 overflow-hidden rounded-t-xl">
        <Image
          src={image}
          alt={name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
        <div className="absolute bottom-3 left-3 right-3">
          <h3 className="text-white font-heading font-semibold text-lg mb-1 truncate">
            {name}
          </h3>
          <div className="flex items-center space-x-2 text-white/90 text-sm">
            <Icon name="MapPin" size={14} />
            <span>{room}</span>
            <span>•</span>
            <span>{grade}</span>
          </div>
        </div>
        <div className={`absolute top-3 right-3 w-3 h-3 rounded-full ${color}`}></div>
      </div>

      {/* Class Details */}
      <div className="p-4">
        {/* Schedule and Students */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2 text-text-secondary text-sm">
            <Icon name="Clock" size={14} />
            <span className="truncate">{schedule}</span>
          </div>
          <div className="flex items-center space-x-1 text-text-secondary text-sm">
            <Icon name="Users" size={14} />
            <span>{students}</span>
          </div>
        </div>

        {/* Next Class */}
        <div className="mb-4">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name="Calendar" size={14} className="text-primary" />
            <span className="text-sm font-medium text-text-primary">Next Class</span>
          </div>
          <p className="text-sm text-text-secondary pl-5">{nextClass}</p>
        </div>

        {/* Recent Assignment */}
        <div className="mb-4">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name="FileText" size={14} className="text-accent" />
            <span className="text-sm font-medium text-text-primary">Recent Assignment</span>
          </div>
          <p className="text-sm text-text-secondary pl-5 truncate">{recentAssignment}</p>
        </div>

        {/* Stats Row */}
        <div className="flex items-center justify-between pt-4 border-t border-border">
          <div className="text-center">
            <div className="text-lg font-bold text-error-600">{pendingSubmissions}</div>
            <div className="text-xs text-text-secondary">Pending</div>
          </div>
          <div className="text-center">
            <div className={`text-lg font-bold ${getGradeColor(averageGrade)}`}>
              {averageGrade}%
            </div>
            <div className="text-xs text-text-secondary">Avg Grade</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-primary">{students}</div>
            <div className="text-xs text-text-secondary">Students</div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="flex items-center space-x-2 mt-4 pt-4 border-t border-border">
          <button className="flex-1 bg-primary hover:bg-primary-700 text-white px-3 py-2 rounded-lg text-sm font-medium transition-micro flex items-center justify-center space-x-1">
            <Icon name="Users" size={14} />
            <span>Roster</span>
          </button>
          <button className="flex-1 bg-secondary-100 hover:bg-secondary-200 text-text-primary px-3 py-2 rounded-lg text-sm font-medium transition-micro flex items-center justify-center space-x-1">
            <Icon name="Award" size={14} />
            <span>Grades</span>
          </button>
          <button className="p-2 text-text-secondary hover:text-primary hover:bg-secondary-50 rounded-lg transition-micro">
            <Icon name="MessageSquare" size={16} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ClassOverviewCard;