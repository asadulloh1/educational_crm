import React, { useState } from 'react';
import Icon from 'components/AppIcon';

const RecentActivity = () => {
  const [activeTab, setActiveTab] = useState('assignments');

  // Mock recent activities data
  const recentActivities = {
    assignments: [
      {
        id: 1,
        title: "Quadratic Equations Quiz",
        class: "Algebra II - Period 1",
        type: "quiz",
        status: "graded",
        submissions: 28,
        totalStudents: 28,
        averageScore: 87,
        dueDate: "2024-01-12",
        createdAt: "2024-01-10",
        icon: "FileText",
        color: "bg-success-500"
      },
      {
        id: 2,
        title: "Derivatives Practice Problems",
        class: "Calculus - Period 3",
        type: "homework",
        status: "pending",
        submissions: 14,
        totalStudents: 22,
        averageScore: null,
        dueDate: "2024-01-15",
        createdAt: "2024-01-13",
        icon: "BookOpen",
        color: "bg-warning-500"
      },
      {
        id: 3,
        title: "Statistics Project Proposal",
        class: "Statistics - Period 5",
        type: "project",
        status: "active",
        submissions: 8,
        totalStudents: 25,
        averageScore: null,
        dueDate: "2024-01-20",
        createdAt: "2024-01-08",
        icon: "BarChart3",
        color: "bg-primary-500"
      }
    ],
    grades: [
      {
        id: 1,
        student: "Emma Thompson",
        assignment: "Quadratic Equations Quiz",
        class: "Algebra II - Period 1",
        score: 94,
        maxScore: 100,
        gradedAt: "2024-01-13",
        feedback: "Excellent work on complex problems!",
        icon: "Award",
        color: "bg-success-500"
      },
      {
        id: 2,
        student: "Michael Rodriguez",
        assignment: "Calculus Midterm",
        class: "Calculus - Period 3",
        score: 78,
        maxScore: 100,
        gradedAt: "2024-01-12",
        feedback: "Good understanding, needs work on integration techniques.",
        icon: "Award",
        color: "bg-warning-500"
      },
      {
        id: 3,
        student: "Sarah Chen",
        assignment: "Statistics Homework #5",
        class: "Statistics - Period 5",
        score: 92,
        maxScore: 100,
        gradedAt: "2024-01-11",
        feedback: "Great analysis of probability distributions!",
        icon: "Award",
        color: "bg-success-500"
      }
    ],
    communications: [
      {
        id: 1,
        type: "parent_message",
        from: "Mrs. Anderson",
        subject: "Emma\'s Progress in Algebra",
        message: "I wanted to discuss Emma\'s recent improvement in algebra. She seems to be grasping the concepts much better now.",
        timestamp: "2024-01-13 2:30 PM",
        status: "unread",
        icon: "MessageSquare",
        color: "bg-primary-500"
      },
      {
        id: 2,
        type: "announcement",
        title: "Class Schedule Change",
        message: "Tomorrow\'s Calculus class will be moved to Room 301 due to maintenance in Room 204.",
        timestamp: "2024-01-13 10:15 AM",
        status: "sent",
        recipients: 22,
        icon: "Megaphone",
        color: "bg-accent-500"
      },
      {
        id: 3,
        type: "student_question",
        from: "Jake Wilson",
        subject: "Question about Homework #7",
        message: "Hi Ms. Johnson, I\'m having trouble with problem #15 on the derivatives worksheet. Could you help explain the chain rule application?",
        timestamp: "2024-01-12 8:45 PM",
        status: "replied",
        icon: "HelpCircle",
        color: "bg-secondary-500"
      }
    ]
  };

  const tabs = [
    { key: 'assignments', label: 'Recent Assignments', icon: 'FileText' },
    { key: 'grades', label: 'Recent Grades', icon: 'Award' },
    { key: 'communications', label: 'Communications', icon: 'MessageSquare' }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'graded': case'sent': case'replied':
        return 'text-success-600 bg-success-50';
      case 'pending': case'unread':
        return 'text-warning-600 bg-warning-50';
      case 'active':
        return 'text-primary-600 bg-primary-50';
      default:
        return 'text-text-secondary bg-secondary-50';
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const renderAssignmentItem = (assignment) => (
    <div key={assignment.id} className="flex items-start space-x-4 p-4 rounded-lg hover:bg-secondary-50 transition-micro">
      <div className={`w-10 h-10 ${assignment.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
        <Icon name={assignment.icon} size={20} color="white" />
      </div>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between">
          <div>
            <h4 className="text-sm font-medium text-text-primary mb-1">
              {assignment.title}
            </h4>
            <p className="text-xs text-text-secondary mb-2">
              {assignment.class} • Due {formatDate(assignment.dueDate)}
            </p>
          </div>
          <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(assignment.status)}`}>
            {assignment.status.charAt(0).toUpperCase() + assignment.status.slice(1)}
          </span>
        </div>
        
        <div className="flex items-center space-x-4 text-xs text-text-secondary">
          <span>{assignment.submissions}/{assignment.totalStudents} submitted</span>
          {assignment.averageScore && (
            <span>Avg: {assignment.averageScore}%</span>
          )}
          <span>Created {formatDate(assignment.createdAt)}</span>
        </div>
        
        {/* Progress Bar */}
        <div className="mt-2">
          <div className="w-full bg-secondary-200 rounded-full h-1.5">
            <div 
              className="bg-primary h-1.5 rounded-full transition-all duration-300"
              style={{ width: `${(assignment.submissions / assignment.totalStudents) * 100}%` }}
            ></div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderGradeItem = (grade) => (
    <div key={grade.id} className="flex items-start space-x-4 p-4 rounded-lg hover:bg-secondary-50 transition-micro">
      <div className={`w-10 h-10 ${grade.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
        <Icon name={grade.icon} size={20} color="white" />
      </div>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between">
          <div>
            <h4 className="text-sm font-medium text-text-primary mb-1">
              {grade.student}
            </h4>
            <p className="text-xs text-text-secondary mb-2">
              {grade.assignment} • {grade.class}
            </p>
          </div>
          <div className="text-right">
            <div className="text-lg font-bold text-text-primary">
              {grade.score}/{grade.maxScore}
            </div>
            <div className="text-xs text-text-secondary">
              {Math.round((grade.score / grade.maxScore) * 100)}%
            </div>
          </div>
        </div>
        
        {grade.feedback && (
          <div className="mt-2 p-2 bg-secondary-50 rounded text-xs text-text-secondary">
            <Icon name="MessageCircle" size={12} className="inline mr-1" />
            {grade.feedback}
          </div>
        )}
        
        <div className="mt-2 text-xs text-text-secondary">
          Graded on {formatDate(grade.gradedAt)}
        </div>
      </div>
    </div>
  );

  const renderCommunicationItem = (comm) => (
    <div key={comm.id} className="flex items-start space-x-4 p-4 rounded-lg hover:bg-secondary-50 transition-micro">
      <div className={`w-10 h-10 ${comm.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
        <Icon name={comm.icon} size={20} color="white" />
      </div>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between">
          <div>
            <h4 className="text-sm font-medium text-text-primary mb-1">
              {comm.subject || comm.title}
            </h4>
            {comm.from && (
              <p className="text-xs text-text-secondary mb-2">
                From: {comm.from}
              </p>
            )}
          </div>
          <div className="flex items-center space-x-2">
            {comm.recipients && (
              <span className="text-xs text-text-secondary">
                {comm.recipients} recipients
              </span>
            )}
            <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(comm.status)}`}>
              {comm.status.charAt(0).toUpperCase() + comm.status.slice(1)}
            </span>
          </div>
        </div>
        
        <p className="text-xs text-text-secondary mb-2 line-clamp-2">
          {comm.message}
        </p>
        
        <div className="text-xs text-text-secondary">
          {comm.timestamp}
        </div>
      </div>
    </div>
  );

  return (
    <div className="bg-surface rounded-xl shadow-card border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-heading font-semibold text-text-primary">
          Recent Activity
        </h2>
        <button className="text-primary hover:text-primary-700 text-sm font-medium flex items-center space-x-1">
          <span>View All</span>
          <Icon name="ArrowRight" size={16} />
        </button>
      </div>

      {/* Tab Navigation */}
      <div className="flex items-center space-x-1 mb-6 bg-secondary-50 rounded-lg p-1">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`flex-1 flex items-center justify-center space-x-2 px-4 py-2 text-sm font-medium rounded-md transition-micro ${
              activeTab === tab.key
                ? 'bg-surface text-primary shadow-sm'
                : 'text-text-secondary hover:text-text-primary'
            }`}
          >
            <Icon name={tab.icon} size={16} />
            <span className="hidden sm:inline">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="space-y-2 max-h-96 overflow-y-auto">
        {activeTab === 'assignments' && recentActivities.assignments.map(renderAssignmentItem)}
        {activeTab === 'grades' && recentActivities.grades.map(renderGradeItem)}
        {activeTab === 'communications' && recentActivities.communications.map(renderCommunicationItem)}
      </div>

      {/* Empty State */}
      {recentActivities[activeTab].length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name={tabs.find(t => t.key === activeTab)?.icon} size={32} className="text-text-secondary" />
          </div>
          <p className="text-text-secondary">No recent {activeTab} to display</p>
        </div>
      )}
    </div>
  );
};

export default RecentActivity;