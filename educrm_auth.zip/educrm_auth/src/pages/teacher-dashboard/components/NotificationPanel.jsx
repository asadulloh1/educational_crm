import React, { useState } from 'react';
import Icon from 'components/AppIcon';

const NotificationPanel = ({ notifications }) => {
  const [filter, setFilter] = useState('all');

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high':
        return 'text-error-600 bg-error-50';
      case 'medium':
        return 'text-warning-600 bg-warning-50';
      case 'low':
        return 'text-success-600 bg-success-50';
      default:
        return 'text-text-secondary bg-secondary-50';
    }
  };

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'grade':
        return 'FileText';
      case 'message':
        return 'MessageSquare';
      case 'announcement':
        return 'Megaphone';
      case 'reminder':
        return 'Clock';
      default:
        return 'Bell';
    }
  };

  const filteredNotifications = notifications.filter(notification => {
    if (filter === 'all') return true;
    return notification.priority === filter;
  });

  const unreadCount = notifications.filter(n => n.priority === 'high').length;

  return (
    <div className="bg-surface rounded-xl shadow-card border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <h3 className="text-lg font-heading font-semibold text-text-primary">
            Notifications
          </h3>
          {unreadCount > 0 && (
            <span className="bg-error text-white text-xs px-2 py-1 rounded-full font-medium">
              {unreadCount}
            </span>
          )}
        </div>
        <button className="text-text-secondary hover:text-primary text-sm">
          <Icon name="Settings" size={16} />
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center space-x-1 mb-4 bg-secondary-50 rounded-lg p-1">
        {[
          { key: 'all', label: 'All' },
          { key: 'high', label: 'Urgent' },
          { key: 'medium', label: 'Important' },
          { key: 'low', label: 'Info' }
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setFilter(tab.key)}
            className={`flex-1 px-3 py-1.5 text-xs font-medium rounded-md transition-micro ${
              filter === tab.key
                ? 'bg-surface text-primary shadow-sm'
                : 'text-text-secondary hover:text-text-primary'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Notifications List */}
      <div className="space-y-3 max-h-80 overflow-y-auto">
        {filteredNotifications.length > 0 ? (
          filteredNotifications.map((notification) => (
            <div
              key={notification.id}
              className="flex items-start space-x-3 p-3 rounded-lg hover:bg-secondary-50 transition-micro cursor-pointer group"
            >
              <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${getPriorityColor(notification.priority)}`}>
                <Icon name={getNotificationIcon(notification.type)} size={14} />
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between">
                  <h4 className="text-sm font-medium text-text-primary group-hover:text-primary transition-colors">
                    {notification.title}
                  </h4>
                  <span className="text-xs text-text-secondary flex-shrink-0 ml-2">
                    {notification.time}
                  </span>
                </div>
                <p className="text-xs text-text-secondary mt-1 leading-relaxed">
                  {notification.message}
                </p>
                
                {/* Priority Badge */}
                <div className="flex items-center justify-between mt-2">
                  <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${getPriorityColor(notification.priority)}`}>
                    {notification.priority.charAt(0).toUpperCase() + notification.priority.slice(1)}
                  </span>
                  
                  {/* Action Buttons */}
                  <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button className="p-1 text-text-secondary hover:text-primary rounded transition-micro">
                      <Icon name="Eye" size={12} />
                    </button>
                    <button className="p-1 text-text-secondary hover:text-error rounded transition-micro">
                      <Icon name="X" size={12} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-8">
            <div className="w-12 h-12 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <Icon name="Bell" size={24} className="text-text-secondary" />
            </div>
            <p className="text-sm text-text-secondary">No notifications in this category</p>
          </div>
        )}
      </div>

      {/* Action Buttons */}
      <div className="flex items-center space-x-2 mt-4 pt-4 border-t border-border">
        <button className="flex-1 bg-primary hover:bg-primary-700 text-white px-3 py-2 rounded-lg text-sm font-medium transition-micro flex items-center justify-center space-x-1">
          <Icon name="CheckCircle" size={14} />
          <span>Mark All Read</span>
        </button>
        <button className="px-3 py-2 text-text-secondary hover:text-primary hover:bg-secondary-50 rounded-lg text-sm font-medium transition-micro">
          <Icon name="ExternalLink" size={14} />
        </button>
      </div>
    </div>
  );
};

export default NotificationPanel;