import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import RoleBasedHeader from 'components/ui/RoleBasedHeader';
import DashboardSidebar from 'components/ui/DashboardSidebar';
import Icon from 'components/AppIcon';

import ClassOverviewCard from './components/ClassOverviewCard';
import QuickActionsPanel from './components/QuickActionsPanel';
import CalendarWidget from './components/CalendarWidget';
import NotificationPanel from './components/NotificationPanel';
import RecentActivity from './components/RecentActivity';

const TeacherDashboard = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [selectedClass, setSelectedClass] = useState(null);
  const navigate = useNavigate();

  // Mock teacher data
  const teacherData = {
    name: "Sarah Johnson",
    email: "sarah.johnson@school.edu",
    employeeId: "TCH001",
    department: "Mathematics",
    subjects: ["Algebra II", "Calculus", "Statistics"],
    totalStudents: 127,
    totalClasses: 5,
    pendingGrades: 23,
    upcomingMeetings: 4
  };

  // Mock classes data
  const classesData = [
    {
      id: 1,
      name: "Algebra II - Period 1",
      subject: "Mathematics",
      grade: "10th Grade",
      students: 28,
      room: "Room 204",
      schedule: "Mon, Wed, Fri - 8:00 AM",
      nextClass: "Today at 8:00 AM",
      recentAssignment: "Quadratic Equations Quiz",
      pendingSubmissions: 5,
      averageGrade: 87,
      color: "bg-blue-500",
      image: "https://images.unsplash.com/photo-1509228468518-180dd4864904?w=400&h=200&fit=crop"
    },
    {
      id: 2,
      name: "Calculus - Period 3",
      subject: "Mathematics",
      grade: "12th Grade",
      students: 22,
      room: "Room 204",
      schedule: "Mon, Wed, Fri - 10:30 AM",
      nextClass: "Tomorrow at 10:30 AM",
      recentAssignment: "Derivatives Practice",
      pendingSubmissions: 8,
      averageGrade: 91,
      color: "bg-green-500",
      image: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=400&h=200&fit=crop"
    },
    {
      id: 3,
      name: "Statistics - Period 5",
      subject: "Mathematics",
      grade: "11th Grade",
      students: 25,
      room: "Room 204",
      schedule: "Tue, Thu - 1:00 PM",
      nextClass: "Thursday at 1:00 PM",
      recentAssignment: "Probability Distribution",
      pendingSubmissions: 3,
      averageGrade: 84,
      color: "bg-purple-500",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=200&fit=crop"
    },
    {
      id: 4,
      name: "Algebra II - Period 6",
      subject: "Mathematics",
      grade: "10th Grade",
      students: 26,
      room: "Room 204",
      schedule: "Mon, Wed, Fri - 2:30 PM",
      nextClass: "Today at 2:30 PM",
      recentAssignment: "Linear Functions Test",
      pendingSubmissions: 12,
      averageGrade: 79,
      color: "bg-orange-500",
      image: "https://images.unsplash.com/photo-1596495578065-6e0763fa1178?w=400&h=200&fit=crop"
    },
    {
      id: 5,
      name: "AP Calculus BC",
      subject: "Mathematics",
      grade: "12th Grade",
      students: 18,
      room: "Room 204",
      schedule: "Daily - 11:45 AM",
      nextClass: "Today at 11:45 AM",
      recentAssignment: "Integration by Parts",
      pendingSubmissions: 2,
      averageGrade: 94,
      color: "bg-red-500",
      image: "https://images.unsplash.com/photo-1518133910546-b6c2fb7d79e3?w=400&h=200&fit=crop"
    }
  ];

  // Mock upcoming events
  const upcomingEvents = [
    {
      id: 1,
      title: "Parent-Teacher Conference",
      date: "2024-01-15",
      time: "3:00 PM",
      type: "meeting",
      description: "Meeting with Mrs. Anderson about Emma\'s progress"
    },
    {
      id: 2,
      title: "Department Meeting",
      date: "2024-01-16",
      time: "4:00 PM",
      type: "meeting",
      description: "Monthly mathematics department meeting"
    },
    {
      id: 3,
      title: "Calculus Exam",
      date: "2024-01-18",
      time: "10:30 AM",
      type: "exam",
      description: "Chapter 5: Derivatives and Applications"
    },
    {
      id: 4,
      title: "Professional Development",
      date: "2024-01-20",
      time: "9:00 AM",
      type: "training",
      description: "Technology Integration in Mathematics"
    }
  ];

  // Mock notifications
  const notifications = [
    {
      id: 1,
      type: "grade",
      title: "Pending Grade Submissions",
      message: "23 assignments need to be graded",
      time: "2 hours ago",
      priority: "high",
      icon: "FileText"
    },
    {
      id: 2,
      type: "message",
      title: "Parent Message",
      message: "Mrs. Thompson sent a message about Jake\'s homework",
      time: "4 hours ago",
      priority: "medium",
      icon: "MessageSquare"
    },
    {
      id: 3,
      type: "announcement",
      title: "School Announcement",
      message: "Early dismissal on Friday due to weather",
      time: "1 day ago",
      priority: "low",
      icon: "Megaphone"
    },
    {
      id: 4,
      type: "reminder",
      title: "Meeting Reminder",
      message: "Department meeting tomorrow at 4:00 PM",
      time: "1 day ago",
      priority: "medium",
      icon: "Clock"
    }
  ];

  const handleToggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const handleClassSelect = (classData) => {
    setSelectedClass(classData);
  };

  const handleQuickAction = (action) => {
    console.log(`Quick action: ${action}`);
    // Handle navigation or modal opening based on action
  };

  return (
    <div className="min-h-screen bg-background">
      <RoleBasedHeader 
        userRole="teacher" 
        userName={teacherData.name}
        userEmail={teacherData.email}
      />
      
      <div className="flex">
        <DashboardSidebar 
          userRole="teacher"
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={handleToggleSidebar}
        />
        
        <main className={`flex-1 transition-all duration-300 ${isSidebarCollapsed ? 'lg:ml-16' : 'lg:ml-64'}`}>
          <div className="pt-16 px-4 sm:px-6 lg:px-8 pb-8">
            {/* Welcome Section */}
            <div className="mb-8">
              <div className="bg-gradient-to-r from-primary to-primary-700 rounded-xl p-6 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <h1 className="text-2xl font-heading font-bold mb-2">
                      Welcome back, {teacherData.name}!
                    </h1>
                    <p className="text-primary-100 mb-4">
                      Ready to inspire minds today? You have {teacherData.pendingGrades} assignments to grade and {teacherData.upcomingMeetings} meetings scheduled.
                    </p>
                    <div className="flex items-center space-x-6">
                      <div className="flex items-center space-x-2">
                        <Icon name="Users" size={20} className="text-primary-200" />
                        <span className="text-sm">{teacherData.totalStudents} Students</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Icon name="BookOpen" size={20} className="text-primary-200" />
                        <span className="text-sm">{teacherData.totalClasses} Classes</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Icon name="Award" size={20} className="text-primary-200" />
                        <span className="text-sm">{teacherData.department}</span>
                      </div>
                    </div>
                  </div>
                  <div className="hidden lg:block">
                    <div className="w-24 h-24 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                      <Icon name="GraduationCap" size={48} className="text-white" />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Main Content Area - 70% width */}
              <div className="lg:col-span-2 space-y-8">
                {/* Quick Actions Panel */}
                <QuickActionsPanel onAction={handleQuickAction} />

                {/* Class Overview Cards */}
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-heading font-semibold text-text-primary">
                      My Classes
                    </h2>
                    <button className="text-primary hover:text-primary-700 text-sm font-medium flex items-center space-x-1">
                      <span>View All</span>
                      <Icon name="ArrowRight" size={16} />
                    </button>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {classesData.map((classItem) => (
                      <ClassOverviewCard
                        key={classItem.id}
                        classData={classItem}
                        onSelect={handleClassSelect}
                        isSelected={selectedClass?.id === classItem.id}
                      />
                    ))}
                  </div>
                </div>

                {/* Recent Activity */}
                <RecentActivity />
              </div>

              {/* Sidebar - 30% width */}
              <div className="space-y-6">
                {/* Calendar Widget */}
                <CalendarWidget events={upcomingEvents} />

                {/* Notification Panel */}
                <NotificationPanel notifications={notifications} />

                {/* Quick Stats */}
                <div className="bg-surface rounded-xl shadow-card border border-border p-6">
                  <h3 className="text-lg font-heading font-semibold text-text-primary mb-4">
                    Today's Overview
                  </h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-success-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-success-100 rounded-full flex items-center justify-center">
                          <Icon name="CheckCircle" size={16} className="text-success-600" />
                        </div>
                        <span className="text-sm font-medium text-success-700">Classes Today</span>
                      </div>
                      <span className="text-lg font-bold text-success-600">4</span>
                    </div>
                    
                    <div className="flex items-center justify-between p-3 bg-warning-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-warning-100 rounded-full flex items-center justify-center">
                          <Icon name="Clock" size={16} className="text-warning-600" />
                        </div>
                        <span className="text-sm font-medium text-warning-700">Pending Grades</span>
                      </div>
                      <span className="text-lg font-bold text-warning-600">{teacherData.pendingGrades}</span>
                    </div>
                    
                    <div className="flex items-center justify-between p-3 bg-primary-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center">
                          <Icon name="MessageSquare" size={16} className="text-primary-600" />
                        </div>
                        <span className="text-sm font-medium text-primary-700">New Messages</span>
                      </div>
                      <span className="text-lg font-bold text-primary-600">7</span>
                    </div>
                  </div>
                </div>

                {/* Quick Links */}
                <div className="bg-surface rounded-xl shadow-card border border-border p-6">
                  <h3 className="text-lg font-heading font-semibold text-text-primary mb-4">
                    Quick Links
                  </h3>
                  <div className="space-y-2">
                    <button className="w-full text-left px-3 py-2 text-sm text-text-primary hover:bg-secondary-50 rounded-lg transition-micro flex items-center space-x-3">
                      <Icon name="FileText" size={16} className="text-text-secondary" />
                      <span>Lesson Plans</span>
                    </button>
                    <button className="w-full text-left px-3 py-2 text-sm text-text-primary hover:bg-secondary-50 rounded-lg transition-micro flex items-center space-x-3">
                      <Icon name="BarChart3" size={16} className="text-text-secondary" />
                      <span>Grade Reports</span>
                    </button>
                    <button className="w-full text-left px-3 py-2 text-sm text-text-primary hover:bg-secondary-50 rounded-lg transition-micro flex items-center space-x-3">
                      <Icon name="Calendar" size={16} className="text-text-secondary" />
                      <span>Schedule</span>
                    </button>
                    <button className="w-full text-left px-3 py-2 text-sm text-text-primary hover:bg-secondary-50 rounded-lg transition-micro flex items-center space-x-3">
                      <Icon name="Users" size={16} className="text-text-secondary" />
                      <span>Parent Contacts</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default TeacherDashboard;