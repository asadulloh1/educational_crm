import React from 'react';
import Icon from 'components/AppIcon';

const AnnouncementCard = ({ announcement }) => {
  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'border-error bg-error-50';
      case 'medium': return 'border-warning bg-warning-50';
      case 'low': return 'border-success bg-success-50';
      default: return 'border-border bg-surface';
    }
  };

  const getPriorityIcon = (priority) => {
    switch (priority) {
      case 'high': return { name: 'AlertTriangle', color: 'text-error' };
      case 'medium': return { name: 'Info', color: 'text-warning' };
      case 'low': return { name: 'CheckCircle', color: 'text-success' };
      default: return { name: 'Bell', color: 'text-text-secondary' };
    }
  };

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = Math.floor((now - date) / (1000 * 60 * 60));
    
    if (diffInHours < 1) {
      return 'Just now';
    } else if (diffInHours < 24) {
      return `${diffInHours}h ago`;
    } else {
      const diffInDays = Math.floor(diffInHours / 24);
      return `${diffInDays}d ago`;
    }
  };

  const priorityIcon = getPriorityIcon(announcement.priority);

  return (
    <div className={`rounded-lg border-2 p-4 transition-smooth hover:shadow-card ${getPriorityColor(announcement.priority)} ${!announcement.read ? 'ring-2 ring-primary/20' : ''}`}>
      <div className="flex items-start space-x-3">
        <div className="flex-shrink-0">
          <Icon name={priorityIcon.name} size={20} className={priorityIcon.color} />
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between mb-2">
            <h4 className={`font-medium ${!announcement.read ? 'text-text-primary font-semibold' : 'text-text-primary'}`}>
              {announcement.title}
              {!announcement.read && (
                <span className="ml-2 w-2 h-2 bg-primary rounded-full inline-block"></span>
              )}
            </h4>
            <span className="text-xs text-text-secondary whitespace-nowrap ml-2">
              {formatTimestamp(announcement.timestamp)}
            </span>
          </div>
          
          <p className="text-sm text-text-secondary mb-3 line-clamp-2">
            {announcement.content}
          </p>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Icon name="User" size={14} className="text-text-secondary" />
              <span className="text-xs text-text-secondary">{announcement.author}</span>
            </div>
            
            <div className="flex items-center space-x-2">
              {!announcement.read && (
                <button className="text-xs text-primary hover:text-primary-700 font-medium transition-micro">
                  Mark as read
                </button>
              )}
              <button className="p-1 text-text-secondary hover:text-primary hover:bg-white/50 rounded transition-micro">
                <Icon name="MoreHorizontal" size={14} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnnouncementCard;