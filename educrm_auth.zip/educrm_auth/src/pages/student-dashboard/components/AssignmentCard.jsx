import React from 'react';
import Icon from 'components/AppIcon';

const AssignmentCard = ({ assignment }) => {
  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'border-l-error bg-error-50';
      case 'medium': return 'border-l-warning bg-warning-50';
      case 'low': return 'border-l-success bg-success-50';
      default: return 'border-l-secondary-300 bg-secondary-50';
    }
  };

  const getPriorityIcon = (priority) => {
    switch (priority) {
      case 'high': return { name: 'AlertTriangle', color: 'text-error' };
      case 'medium': return { name: 'Clock', color: 'text-warning' };
      case 'low': return { name: 'CheckCircle', color: 'text-success' };
      default: return { name: 'Circle', color: 'text-text-secondary' };
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'homework': return 'FileText';
      case 'essay': return 'PenTool';
      case 'lab': return 'Flask';
      case 'quiz': return 'HelpCircle';
      default: return 'File';
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (date.toDateString() === tomorrow.toDateString()) {
      return 'Tomorrow';
    } else {
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }
  };

  const priorityIcon = getPriorityIcon(assignment.priority);

  return (
    <div className={`bg-surface rounded-lg border-l-4 ${getPriorityColor(assignment.priority)} p-4 hover:shadow-card transition-smooth`}>
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name={getTypeIcon(assignment.type)} size={16} className="text-primary" />
            <h4 className="font-medium text-text-primary">{assignment.title}</h4>
            {assignment.completed && (
              <Icon name="CheckCircle" size={16} className="text-success" />
            )}
          </div>
          
          <p className="text-sm text-text-secondary mb-2">{assignment.course}</p>
          
          <div className="flex items-center space-x-4 text-xs text-text-secondary">
            <div className="flex items-center space-x-1">
              <Icon name="Calendar" size={12} />
              <span>Due {formatDate(assignment.dueDate)}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="Award" size={12} />
              <span>{assignment.points} pts</span>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Icon name={priorityIcon.name} size={16} className={priorityIcon.color} />
          {!assignment.completed && (
            <button className="p-1.5 text-primary hover:bg-primary-50 rounded-lg transition-micro">
              <Icon name="ExternalLink" size={14} />
            </button>
          )}
        </div>
      </div>

      {!assignment.completed && (
        <div className="mt-3 pt-3 border-t border-border">
          <button className="w-full bg-primary hover:bg-primary-700 text-white py-2 px-4 rounded-lg text-sm font-medium transition-micro flex items-center justify-center space-x-2">
            <Icon name="Play" size={14} />
            <span>Start Assignment</span>
          </button>
        </div>
      )}
    </div>
  );
};

export default AssignmentCard;