import React from 'react';
import Icon from 'components/AppIcon';

const ProgressChart = ({ progress }) => {
  const getGradeColor = (grade) => {
    switch (grade) {
      case 'A': return 'bg-success';
      case 'B': return 'bg-primary';
      case 'C': return 'bg-warning';
      case 'D': return 'bg-orange-500';
      case 'F': return 'bg-error';
      default: return 'bg-secondary-300';
    }
  };

  const creditProgress = (progress.completedCredits / progress.totalCredits) * 100;

  return (
    <div className="bg-surface rounded-lg p-6 border border-border">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-heading font-semibold text-text-primary">Academic Progress</h3>
        <button className="text-primary hover:text-primary-700 text-sm font-medium transition-micro">
          View Details
        </button>
      </div>

      {/* GPA Section */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-medium text-text-secondary">Current GPA</span>
          <span className="text-2xl font-bold text-text-primary">{progress.overallGPA}</span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-text-secondary">Semester GPA</span>
          <span className="font-medium text-success">{progress.semesterGPA}</span>
        </div>
      </div>

      {/* Credit Progress */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-text-secondary">Credit Progress</span>
          <span className="text-sm text-text-secondary">
            {progress.completedCredits}/{progress.totalCredits} credits
          </span>
        </div>
        <div className="w-full bg-secondary-200 rounded-full h-3">
          <div 
            className="bg-primary h-3 rounded-full transition-smooth"
            style={{ width: `${creditProgress}%` }}
          ></div>
        </div>
        <div className="text-xs text-text-secondary mt-1">
          {Math.round(creditProgress)}% complete
        </div>
      </div>

      {/* Grade Distribution */}
      <div className="mb-6">
        <h4 className="text-sm font-medium text-text-secondary mb-3">Grade Distribution</h4>
        <div className="space-y-2">
          {progress.gradeDistribution.map((grade) => (
            <div key={grade.grade} className="flex items-center space-x-3">
              <div className="w-8 text-sm font-medium text-text-primary">{grade.grade}</div>
              <div className="flex-1 bg-secondary-200 rounded-full h-2">
                <div 
                  className={`h-2 rounded-full transition-smooth ${getGradeColor(grade.grade)}`}
                  style={{ width: `${grade.percentage}%` }}
                ></div>
              </div>
              <div className="w-12 text-sm text-text-secondary text-right">
                {grade.count} ({grade.percentage}%)
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Achievements Preview */}
      <div>
        <h4 className="text-sm font-medium text-text-secondary mb-3">Recent Achievements</h4>
        <div className="flex items-center space-x-2">
          {progress.achievements.filter(a => a.earned).slice(0, 3).map((achievement, index) => (
            <div
              key={index}
              className="flex items-center space-x-1 bg-success-50 text-success-700 px-2 py-1 rounded-full text-xs"
            >
              <Icon name={achievement.icon} size={12} />
              <span>{achievement.name}</span>
            </div>
          ))}
          {progress.achievements.filter(a => a.earned).length > 3 && (
            <span className="text-xs text-text-secondary">
              +{progress.achievements.filter(a => a.earned).length - 3} more
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProgressChart;