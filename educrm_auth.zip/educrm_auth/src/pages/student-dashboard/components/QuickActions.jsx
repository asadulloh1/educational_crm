import React from 'react';
import Icon from 'components/AppIcon';

const QuickActions = () => {
  const quickActions = [
    {
      id: 1,
      title: "Submit Assignment",
      description: "Upload your completed work",
      icon: "Upload",
      color: "bg-primary",
      action: () => console.log("Submit Assignment")
    },
    {
      id: 2,
      title: "Check Grades",
      description: "View your latest scores",
      icon: "Award",
      color: "bg-success",
      action: () => console.log("Check Grades")
    },
    {
      id: 3,
      title: "Message Teacher",
      description: "Ask questions or get help",
      icon: "MessageSquare",
      color: "bg-warning",
      action: () => console.log("Message Teacher")
    },
    {
      id: 4,
      title: "View Schedule",
      description: "Check your class timetable",
      icon: "Calendar",
      color: "bg-purple-500",
      action: () => console.log("View Schedule")
    },
    {
      id: 5,
      title: "Study Resources",
      description: "Access learning materials",
      icon: "BookOpen",
      color: "bg-orange-500",
      action: () => console.log("Study Resources")
    },
    {
      id: 6,
      title: "Join Virtual Class",
      description: "Enter online classroom",
      icon: "Video",
      color: "bg-blue-500",
      action: () => console.log("Join Virtual Class")
    }
  ];

  return (
    <div className="bg-surface rounded-lg p-6 border border-border mb-8">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-heading font-semibold text-text-primary">Quick Actions</h3>
        <button className="text-primary hover:text-primary-700 text-sm font-medium transition-micro">
          Customize
        </button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-1 xl:grid-cols-2 gap-3">
        {quickActions.slice(0, 6).map((action) => (
          <button
            key={action.id}
            onClick={action.action}
            className="flex items-center space-x-3 p-3 rounded-lg hover:bg-secondary-50 transition-micro text-left group"
          >
            <div className={`w-10 h-10 ${action.color} rounded-lg flex items-center justify-center group-hover:scale-105 transition-transform`}>
              <Icon name={action.icon} size={18} color="white" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="font-medium text-text-primary text-sm group-hover:text-primary transition-micro">
                {action.title}
              </h4>
              <p className="text-xs text-text-secondary line-clamp-1">
                {action.description}
              </p>
            </div>
          </button>
        ))}
      </div>

      {/* Emergency Contact */}
      <div className="mt-4 pt-4 border-t border-border">
        <button className="w-full flex items-center justify-center space-x-2 py-2 px-4 bg-error-50 hover:bg-error-100 text-error-700 rounded-lg transition-micro">
          <Icon name="Phone" size={16} />
          <span className="text-sm font-medium">Emergency Contact</span>
        </button>
      </div>
    </div>
  );
};

export default QuickActions;