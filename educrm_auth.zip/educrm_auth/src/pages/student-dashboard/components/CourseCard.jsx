import React from 'react';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const CourseCard = ({ course }) => {
  const getProgressColor = (progress) => {
    if (progress >= 80) return 'bg-success';
    if (progress >= 60) return 'bg-warning';
    return 'bg-error';
  };

  const getGradeColor = (grade) => {
    if (grade.startsWith('A')) return 'text-success bg-success-50';
    if (grade.startsWith('B')) return 'text-primary bg-primary-50';
    if (grade.startsWith('C')) return 'text-warning bg-warning-50';
    return 'text-error bg-error-50';
  };

  return (
    <div className="bg-surface rounded-xl p-6 border border-border hover:shadow-card transition-smooth">
      {/* Course Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className={`w-12 h-12 ${course.color} rounded-lg flex items-center justify-center`}>
            <Icon name="BookOpen" size={20} color="white" />
          </div>
          <div>
            <h3 className="font-heading font-semibold text-text-primary text-lg">{course.name}</h3>
            <p className="text-text-secondary text-sm">{course.instructor}</p>
          </div>
        </div>
        <div className={`px-3 py-1 rounded-full text-sm font-medium ${getGradeColor(course.grade)}`}>
          {course.grade}
        </div>
      </div>

      {/* Instructor Info */}
      <div className="flex items-center space-x-3 mb-4">
        <Image 
          src={course.instructorAvatar}
          alt={course.instructor}
          className="w-8 h-8 rounded-full object-cover"
        />
        <div className="flex-1">
          <div className="flex items-center justify-between">
            <span className="text-sm text-text-secondary">Instructor</span>
            <span className="text-sm text-text-secondary">{course.totalStudents} students</span>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-text-primary">Course Progress</span>
          <span className="text-sm text-text-secondary">{course.progress}%</span>
        </div>
        <div className="w-full bg-secondary-200 rounded-full h-2">
          <div 
            className={`h-2 rounded-full transition-smooth ${getProgressColor(course.progress)}`}
            style={{ width: `${course.progress}%` }}
          ></div>
        </div>
      </div>

      {/* Course Details */}
      <div className="space-y-3">
        <div className="flex items-center justify-between py-2 px-3 bg-secondary-50 rounded-lg">
          <div className="flex items-center space-x-2">
            <Icon name="Clock" size={16} className="text-text-secondary" />
            <span className="text-sm text-text-secondary">Next Class</span>
          </div>
          <span className="text-sm font-medium text-text-primary">{course.nextClass}</span>
        </div>

        <div className="flex items-center justify-between py-2 px-3 bg-warning-50 rounded-lg">
          <div className="flex items-center space-x-2">
            <Icon name="FileText" size={16} className="text-warning" />
            <span className="text-sm text-warning-700">Upcoming Assignment</span>
          </div>
          <span className="text-sm font-medium text-warning-700">{course.assignmentDue}</span>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center space-x-2 mt-4 pt-4 border-t border-border">
        <button className="flex-1 bg-primary hover:bg-primary-700 text-white py-2 px-4 rounded-lg text-sm font-medium transition-micro flex items-center justify-center space-x-2">
          <Icon name="Play" size={16} />
          <span>Continue Learning</span>
        </button>
        <button className="p-2 text-text-secondary hover:text-primary hover:bg-secondary-50 rounded-lg transition-micro">
          <Icon name="MessageSquare" size={16} />
        </button>
        <button className="p-2 text-text-secondary hover:text-primary hover:bg-secondary-50 rounded-lg transition-micro">
          <Icon name="MoreHorizontal" size={16} />
        </button>
      </div>
    </div>
  );
};

export default CourseCard;