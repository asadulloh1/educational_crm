import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import RoleBasedHeader from 'components/ui/RoleBasedHeader';
import MobileTabBar from 'components/ui/MobileTabBar';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';
import CourseCard from './components/CourseCard';
import AssignmentCard from './components/AssignmentCard';
import AnnouncementCard from './components/AnnouncementCard';
import ProgressChart from './components/ProgressChart';
import QuickActions from './components/QuickActions';

const StudentDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [notifications, setNotifications] = useState([]);
  const navigate = useNavigate();

  // Mock student data
  const studentData = {
    name: "Alex Johnson",
    email: "alex.johnson@student.edu",
    studentId: "STU2024001",
    grade: "11th Grade",
    gpa: 3.85,
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face"
  };

  const currentCourses = [
    {
      id: 1,
      name: "Advanced Mathematics",
      instructor: "Dr. Sarah Wilson",
      instructorAvatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
      color: "bg-blue-500",
      progress: 78,
      nextClass: "Today, 2:00 PM",
      upcomingAssignment: "Calculus Problem Set",
      assignmentDue: "Tomorrow",
      grade: "A-",
      totalStudents: 24
    },
    {
      id: 2,
      name: "English Literature",
      instructor: "Prof. Michael Chen",
      instructorAvatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
      color: "bg-green-500",
      progress: 85,
      nextClass: "Tomorrow, 10:00 AM",
      upcomingAssignment: "Shakespeare Essay",
      assignmentDue: "Friday",
      grade: "A",
      totalStudents: 28
    },
    {
      id: 3,
      name: "Physics",
      instructor: "Dr. Emily Rodriguez",
      instructorAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
      color: "bg-purple-500",
      progress: 72,
      nextClass: "Wednesday, 1:00 PM",
      upcomingAssignment: "Lab Report",
      assignmentDue: "Next Monday",
      grade: "B+",
      totalStudents: 22
    },
    {
      id: 4,
      name: "World History",
      instructor: "Mr. David Thompson",
      instructorAvatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150&h=150&fit=crop&crop=face",
      color: "bg-orange-500",
      progress: 90,
      nextClass: "Thursday, 11:00 AM",
      upcomingAssignment: "Research Project",
      assignmentDue: "Next Week",
      grade: "A",
      totalStudents: 26
    }
  ];

  const upcomingAssignments = [
    {
      id: 1,
      title: "Calculus Problem Set",
      course: "Advanced Mathematics",
      dueDate: "2024-12-20",
      priority: "high",
      completed: false,
      type: "homework",
      points: 50
    },
    {
      id: 2,
      title: "Shakespeare Essay",
      course: "English Literature",
      dueDate: "2024-12-22",
      priority: "medium",
      completed: false,
      type: "essay",
      points: 100
    },
    {
      id: 3,
      title: "Physics Lab Report",
      course: "Physics",
      dueDate: "2024-12-23",
      priority: "medium",
      completed: false,
      type: "lab",
      points: 75
    },
    {
      id: 4,
      title: "History Quiz",
      course: "World History",
      dueDate: "2024-12-21",
      priority: "low",
      completed: true,
      type: "quiz",
      points: 25
    }
  ];

  const recentAnnouncements = [
    {
      id: 1,
      title: "Winter Break Schedule",
      content: "Classes will resume on January 8th, 2025. Please check your email for detailed schedule updates and any changes to your course assignments.",
      author: "Academic Office",
      timestamp: "2024-12-19T10:30:00Z",
      read: false,
      priority: "high"
    },
    {
      id: 2,
      title: "Library Extended Hours",
      content: "The library will be open until 10 PM during finals week to provide additional study space for students.",
      author: "Library Services",
      timestamp: "2024-12-18T14:15:00Z",
      read: true,
      priority: "medium"
    },
    {
      id: 3,
      title: "New Online Resources Available",
      content: "We\'ve added new digital textbooks and research databases to help with your studies. Access them through the student portal.",
      author: "IT Department",
      timestamp: "2024-12-17T09:00:00Z",
      read: true,
      priority: "low"
    }
  ];

  const academicProgress = {
    overallGPA: 3.85,
    semesterGPA: 3.92,
    completedCredits: 45,
    totalCredits: 60,
    achievements: [
      { name: "Dean\'s List", earned: true, icon: "Award" },
      { name: "Perfect Attendance", earned: true, icon: "Calendar" },
      { name: "Honor Roll", earned: false, icon: "Star" },
      { name: "Academic Excellence", earned: false, icon: "Trophy" }
    ],
    gradeDistribution: [
      { grade: "A", count: 6, percentage: 40 },
      { grade: "B", count: 7, percentage: 47 },
      { grade: "C", count: 2, percentage: 13 },
      { grade: "D", count: 0, percentage: 0 },
      { grade: "F", count: 0, percentage: 0 }
    ]
  };

  useEffect(() => {
    // Simulate loading notifications
    const unreadCount = recentAnnouncements.filter(ann => !ann.read).length;
    setNotifications(Array(unreadCount).fill(null));
  }, []);

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'text-error bg-error-50 border-error-200';
      case 'medium': return 'text-warning bg-warning-50 border-warning-200';
      case 'low': return 'text-success bg-success-50 border-success-200';
      default: return 'text-text-secondary bg-secondary-50 border-border';
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (date.toDateString() === tomorrow.toDateString()) {
      return 'Tomorrow';
    } else {
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <RoleBasedHeader 
        userRole="student" 
        userName={studentData.name}
        userEmail={studentData.email}
      />
      
      <main className="pt-16 pb-20 lg:pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {/* Welcome Section */}
          <div className="mb-8">
            <div className="bg-gradient-to-r from-primary to-primary-700 rounded-xl p-6 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-heading font-bold mb-2">
                    Welcome back, {studentData.name.split(' ')[0]}! 👋
                  </h1>
                  <p className="text-primary-100 mb-4">
                    You have {upcomingAssignments.filter(a => !a.completed).length} pending assignments and {notifications.length} new notifications
                  </p>
                  <div className="flex items-center space-x-4 text-sm">
                    <div className="flex items-center space-x-2">
                      <Icon name="GraduationCap" size={16} />
                      <span>{studentData.grade}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Icon name="Award" size={16} />
                      <span>GPA: {studentData.gpa}</span>
                    </div>
                  </div>
                </div>
                <div className="hidden sm:block">
                  <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center">
                    <Image 
                      src={studentData.avatar}
                      alt={studentData.name}
                      className="w-16 h-16 rounded-full object-cover"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Mobile Tab Navigation */}
          <div className="lg:hidden mb-6">
            <div className="flex space-x-1 bg-secondary-100 p-1 rounded-lg">
              {[
                { key: 'overview', label: 'Overview', icon: 'Home' },
                { key: 'courses', label: 'Courses', icon: 'BookOpen' },
                { key: 'assignments', label: 'Tasks', icon: 'FileText' },
                { key: 'progress', label: 'Progress', icon: 'TrendingUp' }
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => handleTabChange(tab.key)}
                  className={`flex-1 flex items-center justify-center space-x-2 py-2 px-3 rounded-md text-sm font-medium transition-micro ${
                    activeTab === tab.key
                      ? 'bg-white text-primary shadow-sm'
                      : 'text-text-secondary hover:text-text-primary'
                  }`}
                >
                  <Icon name={tab.icon} size={16} />
                  <span className="hidden sm:inline">{tab.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Desktop Layout */}
          <div className="hidden lg:grid lg:grid-cols-12 lg:gap-8">
            {/* Main Content */}
            <div className="lg:col-span-8">
              {/* Current Courses */}
              <div className="mb-8">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-heading font-semibold text-text-primary">Current Courses</h2>
                  <button className="text-primary hover:text-primary-700 text-sm font-medium transition-micro">
                    View All
                  </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {currentCourses.map((course) => (
                    <CourseCard key={course.id} course={course} />
                  ))}
                </div>
              </div>

              {/* Recent Announcements */}
              <div className="mb-8">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-heading font-semibold text-text-primary">Recent Announcements</h2>
                  <button className="text-primary hover:text-primary-700 text-sm font-medium transition-micro">
                    View All
                  </button>
                </div>
                <div className="space-y-4">
                  {recentAnnouncements.slice(0, 3).map((announcement) => (
                    <AnnouncementCard key={announcement.id} announcement={announcement} />
                  ))}
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-4">
              {/* Quick Actions */}
              <QuickActions />

              {/* Upcoming Assignments */}
              <div className="mb-8">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-heading font-semibold text-text-primary">Upcoming Tasks</h3>
                  <button className="text-primary hover:text-primary-700 text-sm font-medium transition-micro">
                    View All
                  </button>
                </div>
                <div className="space-y-3">
                  {upcomingAssignments.filter(a => !a.completed).slice(0, 4).map((assignment) => (
                    <AssignmentCard key={assignment.id} assignment={assignment} />
                  ))}
                </div>
              </div>

              {/* Progress Overview */}
              <ProgressChart progress={academicProgress} />
            </div>
          </div>

          {/* Mobile Content */}
          <div className="lg:hidden">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* Quick Stats */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-surface rounded-lg p-4 border border-border">
                    <div className="flex items-center space-x-2 mb-2">
                      <Icon name="BookOpen" size={16} className="text-primary" />
                      <span className="text-sm font-medium text-text-secondary">Active Courses</span>
                    </div>
                    <p className="text-2xl font-bold text-text-primary">{currentCourses.length}</p>
                  </div>
                  <div className="bg-surface rounded-lg p-4 border border-border">
                    <div className="flex items-center space-x-2 mb-2">
                      <Icon name="FileText" size={16} className="text-warning" />
                      <span className="text-sm font-medium text-text-secondary">Pending Tasks</span>
                    </div>
                    <p className="text-2xl font-bold text-text-primary">
                      {upcomingAssignments.filter(a => !a.completed).length}
                    </p>
                  </div>
                </div>

                {/* Quick Actions Mobile */}
                <QuickActions />

                {/* Recent Announcements Mobile */}
                <div>
                  <h3 className="text-lg font-heading font-semibold text-text-primary mb-4">Recent Updates</h3>
                  <div className="space-y-3">
                    {recentAnnouncements.slice(0, 2).map((announcement) => (
                      <AnnouncementCard key={announcement.id} announcement={announcement} />
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'courses' && (
              <div className="space-y-4">
                {currentCourses.map((course) => (
                  <CourseCard key={course.id} course={course} />
                ))}
              </div>
            )}

            {activeTab === 'assignments' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-heading font-semibold text-text-primary">All Assignments</h3>
                  <div className="flex items-center space-x-2">
                    <button className="p-2 text-text-secondary hover:text-primary hover:bg-secondary-50 rounded-lg transition-micro">
                      <Icon name="Filter" size={16} />
                    </button>
                    <button className="p-2 text-text-secondary hover:text-primary hover:bg-secondary-50 rounded-lg transition-micro">
                      <Icon name="Search" size={16} />
                    </button>
                  </div>
                </div>
                {upcomingAssignments.map((assignment) => (
                  <AssignmentCard key={assignment.id} assignment={assignment} />
                ))}
              </div>
            )}

            {activeTab === 'progress' && (
              <div className="space-y-6">
                <ProgressChart progress={academicProgress} />
                
                {/* Achievements */}
                <div className="bg-surface rounded-lg p-6 border border-border">
                  <h3 className="text-lg font-heading font-semibold text-text-primary mb-4">Achievements</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {academicProgress.achievements.map((achievement, index) => (
                      <div
                        key={index}
                        className={`p-4 rounded-lg border-2 transition-micro ${
                          achievement.earned
                            ? 'bg-success-50 border-success-200 text-success-700' :'bg-secondary-50 border-secondary-200 text-text-secondary'
                        }`}
                      >
                        <div className="flex flex-col items-center text-center">
                          <Icon 
                            name={achievement.icon} 
                            size={24} 
                            className={achievement.earned ? 'text-success' : 'text-text-secondary'} 
                          />
                          <span className="text-sm font-medium mt-2">{achievement.name}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      <MobileTabBar userRole="student" />
    </div>
  );
};

export default StudentDashboard;