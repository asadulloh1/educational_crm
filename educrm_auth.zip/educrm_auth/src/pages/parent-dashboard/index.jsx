import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import RoleBasedHeader from 'components/ui/RoleBasedHeader';
import MobileTabBar from 'components/ui/MobileTabBar';
import Icon from 'components/AppIcon';

import StudentCard from './components/StudentCard';
import NotificationCard from './components/NotificationCard';
import CommunicationHub from './components/CommunicationHub';
import QuickActions from './components/QuickActions';
import GradeTracking from './components/GradeTracking';

const ParentDashboard = () => {
  const [activeStudentTab, setActiveStudentTab] = useState(0);
  const [showNotifications, setShowNotifications] = useState(true);
  const navigate = useNavigate();

  // Mock data for connected students
  const connectedStudents = [
    {
      id: 1,
      name: "Emma Johnson",
      grade: "8th Grade",
      photo: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&h=150&fit=crop&crop=face",
      currentGPA: 3.8,
      recentGrades: [
        { subject: "Mathematics", grade: "A-", date: "2024-01-15" },
        { subject: "Science", grade: "B+", date: "2024-01-14" },
        { subject: "English", grade: "A", date: "2024-01-12" }
      ],
      upcomingAssignments: [
        { title: "History Essay", dueDate: "2024-01-20", subject: "History" },
        { title: "Math Quiz", dueDate: "2024-01-18", subject: "Mathematics" }
      ],
      teacherMessages: [
        {
          teacher: "Ms. Rodriguez",
          subject: "Mathematics",
          message: "Emma is showing excellent progress in algebra. Keep up the great work!",
          date: "2024-01-15",
          priority: "normal"
        }
      ],
      attendance: { present: 18, absent: 2, late: 1 },
      nextParentTeacher: "2024-01-25 at 3:00 PM"
    },
    {
      id: 2,
      name: "Alex Johnson",
      grade: "5th Grade",
      photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
      currentGPA: 3.6,
      recentGrades: [
        { subject: "Reading", grade: "A", date: "2024-01-16" },
        { subject: "Math", grade: "B", date: "2024-01-15" },
        { subject: "Science", grade: "B+", date: "2024-01-13" }
      ],
      upcomingAssignments: [
        { title: "Science Project", dueDate: "2024-01-22", subject: "Science" },
        { title: "Reading Report", dueDate: "2024-01-19", subject: "Reading" }
      ],
      teacherMessages: [
        {
          teacher: "Mr. Thompson",
          subject: "Science",
          message: "Alex needs to submit the missing lab worksheet from last week.",
          date: "2024-01-14",
          priority: "high"
        }
      ],
      attendance: { present: 19, absent: 1, late: 0 },
      nextParentTeacher: "2024-01-26 at 2:30 PM"
    }
  ];

  // Mock notifications data
  const notifications = [
    {
      id: 1,
      type: "grade",
      title: "New Grade Posted",
      message: "Emma received an A- in Mathematics",
      student: "Emma Johnson",
      date: "2024-01-15",
      priority: "normal",
      read: false
    },
    {
      id: 2,
      type: "assignment",
      title: "Missing Assignment Alert",
      message: "Alex has a missing lab worksheet in Science",
      student: "Alex Johnson",
      date: "2024-01-14",
      priority: "high",
      read: false
    },
    {
      id: 3,
      type: "conference",
      title: "Parent-Teacher Conference Scheduled",
      message: "Conference scheduled for Emma - Jan 25 at 3:00 PM",
      student: "Emma Johnson",
      date: "2024-01-13",
      priority: "normal",
      read: true
    },
    {
      id: 4,
      type: "announcement",
      title: "School Event Reminder",
      message: "Science Fair is next Friday. Volunteers needed!",
      student: "All Students",
      date: "2024-01-12",
      priority: "normal",
      read: true
    }
  ];

  // Mock communication data
  const recentMessages = [
    {
      id: 1,
      teacher: "Ms. Rodriguez",
      subject: "Mathematics Progress Update",
      message: `Emma is excelling in her algebra studies and consistently demonstrates strong problem-solving skills. She actively participates in class discussions and helps her peers when they struggle with concepts.

I wanted to reach out to commend her dedication to her studies. Her recent test scores show significant improvement, and she's developing excellent mathematical reasoning abilities.

Please continue to encourage her mathematical exploration at home.`,
      date: "2024-01-15",
      student: "Emma Johnson",
      priority: "normal",
      replied: false
    },
    {
      id: 2,
      teacher: "Mr. Thompson",
      subject: "Missing Assignment - Action Required",
      message: `Alex missed submitting his lab worksheet from our recent experiment on plant growth. This assignment is important for understanding the scientific method we've been studying.

Could you please remind Alex to complete and submit this assignment by Friday? I'm available for extra help during lunch if he needs clarification on any concepts.

Thank you for your support in Alex's education.`,
      date: "2024-01-14",
      student: "Alex Johnson",
      priority: "high",
      replied: false
    }
  ];

  const currentStudent = connectedStudents[activeStudentTab];
  const unreadNotifications = notifications.filter(n => !n.read).length;

  return (
    <div className="min-h-screen bg-background">
      <RoleBasedHeader 
        userRole="parent" 
        userName="Sarah Johnson" 
        userEmail="sarah.johnson@email.com" 
      />
      
      <div className="pt-16 pb-20 lg:pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Welcome Section */}
          <div className="mb-8">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h1 className="text-3xl font-heading font-bold text-text-primary mb-2">
                  Welcome back, Sarah
                </h1>
                <p className="text-text-secondary">
                  Stay connected with your children's educational journey
                </p>
              </div>
              <div className="mt-4 sm:mt-0 flex items-center space-x-4">
                <button
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="relative p-2 text-text-secondary hover:text-primary hover:bg-secondary-50 rounded-lg transition-micro"
                >
                  <Icon name="Bell" size={20} />
                  {unreadNotifications > 0 && (
                    <span className="absolute -top-1 -right-1 bg-accent text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-medium">
                      {unreadNotifications}
                    </span>
                  )}
                </button>
                <button className="bg-primary hover:bg-primary-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-micro flex items-center space-x-2">
                  <Icon name="MessageSquare" size={16} />
                  <span>Message Teachers</span>
                </button>
              </div>
            </div>
          </div>

          {/* Student Tabs - Mobile */}
          <div className="lg:hidden mb-6">
            <div className="flex space-x-1 bg-secondary-100 p-1 rounded-lg">
              {connectedStudents.map((student, index) => (
                <button
                  key={student.id}
                  onClick={() => setActiveStudentTab(index)}
                  className={`flex-1 px-3 py-2 text-sm font-medium rounded-md transition-micro ${
                    activeStudentTab === index
                      ? 'bg-surface text-primary shadow-sm'
                      : 'text-text-secondary hover:text-text-primary'
                  }`}
                >
                  {student.name.split(' ')[0]}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-8">
              {/* Desktop Student Cards */}
              <div className="hidden lg:block mb-8">
                <h2 className="text-xl font-heading font-semibold text-text-primary mb-4">
                  Your Children
                </h2>
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                  {connectedStudents.map((student) => (
                    <StudentCard key={student.id} student={student} />
                  ))}
                </div>
              </div>

              {/* Mobile Single Student View */}
              <div className="lg:hidden mb-8">
                <StudentCard student={currentStudent} />
              </div>

              {/* Grade Tracking */}
              <div className="mb-8">
                <GradeTracking student={currentStudent} />
              </div>

              {/* Communication Hub */}
              <div className="mb-8">
                <CommunicationHub messages={recentMessages} />
              </div>
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-4">
              {/* Notifications */}
              {showNotifications && (
                <div className="mb-8">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-heading font-semibold text-text-primary">
                      Recent Updates
                    </h3>
                    <button
                      onClick={() => setShowNotifications(false)}
                      className="p-1 text-text-secondary hover:text-text-primary transition-micro lg:hidden"
                    >
                      <Icon name="X" size={16} />
                    </button>
                  </div>
                  <div className="space-y-3">
                    {notifications.slice(0, 4).map((notification) => (
                      <NotificationCard key={notification.id} notification={notification} />
                    ))}
                  </div>
                  <button className="w-full mt-4 text-primary hover:text-primary-700 text-sm font-medium transition-micro">
                    View All Notifications
                  </button>
                </div>
              )}

              {/* Quick Actions */}
              <div className="mb-8">
                <QuickActions />
              </div>

              {/* Upcoming Events */}
              <div className="bg-surface rounded-lg border border-border p-6">
                <h3 className="text-lg font-heading font-semibold text-text-primary mb-4">
                  Upcoming Events
                </h3>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-text-primary">Parent-Teacher Conference</p>
                      <p className="text-xs text-text-secondary">Emma - Jan 25, 3:00 PM</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-accent rounded-full mt-2"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-text-primary">Science Fair</p>
                      <p className="text-xs text-text-secondary">Jan 26, 6:00 PM - 8:00 PM</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-success rounded-full mt-2"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-text-primary">Parent-Teacher Conference</p>
                      <p className="text-xs text-text-secondary">Alex - Jan 26, 2:30 PM</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <MobileTabBar userRole="parent" />
    </div>
  );
};

export default ParentDashboard;