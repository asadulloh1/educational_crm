import React from 'react';
import Icon from 'components/AppIcon';

const NotificationCard = ({ notification }) => {
  const getNotificationIcon = (type) => {
    switch (type) {
      case 'grade': return 'Award';
      case 'assignment': return 'FileText';
      case 'conference': return 'Calendar';
      case 'announcement': return 'Megaphone';
      default: return 'Bell';
    }
  };

  const getNotificationColor = (priority) => {
    switch (priority) {
      case 'high': return 'border-l-error bg-error-50';
      case 'normal': return 'border-l-primary bg-primary-50';
      default: return 'border-l-secondary bg-secondary-50';
    }
  };

  const getPriorityBadge = (priority) => {
    if (priority === 'high') {
      return (
        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-error text-white">
          Urgent
        </span>
      );
    }
    return null;
  };

  return (
    <div className={`p-4 rounded-lg border-l-4 ${getNotificationColor(notification.priority)} ${!notification.read ? 'bg-opacity-100' : 'bg-opacity-50'}`}>
      <div className="flex items-start space-x-3">
        <div className={`p-2 rounded-lg ${notification.priority === 'high' ? 'bg-error text-white' : 'bg-primary text-white'}`}>
          <Icon name={getNotificationIcon(notification.type)} size={16} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-1">
            <h4 className="text-sm font-medium text-text-primary truncate">
              {notification.title}
            </h4>
            {getPriorityBadge(notification.priority)}
          </div>
          <p className="text-sm text-text-secondary mb-2">
            {notification.message}
          </p>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-xs text-text-secondary">
              <span>{notification.student}</span>
              <span>•</span>
              <span>{new Date(notification.date).toLocaleDateString()}</span>
            </div>
            {!notification.read && (
              <div className="w-2 h-2 bg-primary rounded-full"></div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotificationCard;