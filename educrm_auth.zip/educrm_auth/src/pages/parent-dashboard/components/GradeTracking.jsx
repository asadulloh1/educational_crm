import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import Icon from 'components/AppIcon';

const GradeTracking = ({ student }) => {
  const [viewMode, setViewMode] = useState('current'); // 'current' or 'trend'

  // Mock grade trend data
  const gradeTrendData = [
    { month: 'Sep', Mathematics: 3.7, Science: 3.5, English: 3.9, History: 3.6 },
    { month: 'Oct', Mathematics: 3.8, Science: 3.6, English: 3.8, History: 3.7 },
    { month: 'Nov', Mathematics: 3.9, Science: 3.7, English: 4.0, History: 3.8 },
    { month: 'Dec', Mathematics: 3.8, Science: 3.8, English: 3.9, History: 3.7 },
    { month: 'Jan', Mathematics: 3.8, Science: 3.6, English: 4.0, History: 3.8 }
  ];

  // Mock current grades data
  const currentGradesData = [
    { subject: 'Math', grade: 3.8, letter: 'A-', color: '#10B981' },
    { subject: 'Science', grade: 3.6, letter: 'B+', color: '#3B82F6' },
    { subject: 'English', grade: 4.0, letter: 'A', color: '#10B981' },
    { subject: 'History', grade: 3.8, letter: 'A-', color: '#10B981' },
    { subject: 'Art', grade: 3.9, letter: 'A-', color: '#10B981' }
  ];

  const getGradeColor = (grade) => {
    if (grade >= 3.7) return 'text-success bg-success-50';
    if (grade >= 3.0) return 'text-primary bg-primary-50';
    if (grade >= 2.0) return 'text-accent bg-accent-50';
    return 'text-error bg-error-50';
  };

  const getProgressPercentage = (grade) => {
    return (grade / 4.0) * 100;
  };

  return (
    <div className="bg-surface rounded-lg border border-border">
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-heading font-semibold text-text-primary flex items-center space-x-2">
            <Icon name="TrendingUp" size={20} />
            <span>Grade Tracking - {student.name}</span>
          </h2>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setViewMode('current')}
              className={`px-3 py-1 text-sm font-medium rounded-lg transition-micro ${
                viewMode === 'current' ?'bg-primary text-white' :'text-text-secondary hover:text-text-primary hover:bg-secondary-50'
              }`}
            >
              Current
            </button>
            <button
              onClick={() => setViewMode('trend')}
              className={`px-3 py-1 text-sm font-medium rounded-lg transition-micro ${
                viewMode === 'trend' ?'bg-primary text-white' :'text-text-secondary hover:text-text-primary hover:bg-secondary-50'
              }`}
            >
              Trends
            </button>
          </div>
        </div>
      </div>

      <div className="p-6">
        {viewMode === 'current' ? (
          <div>
            {/* Overall GPA */}
            <div className="mb-6 p-4 bg-primary-50 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-primary">Current GPA</h3>
                  <p className="text-sm text-primary-700">Overall academic performance</p>
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold text-primary">{student.currentGPA}</div>
                  <div className="text-sm text-primary-700">out of 4.0</div>
                </div>
              </div>
            </div>

            {/* Subject Grades */}
            <div className="space-y-4">
              <h4 className="text-sm font-medium text-text-primary mb-3">Subject Performance</h4>
              {currentGradesData.map((subject, index) => (
                <div key={index} className="p-4 border border-border rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <div className={`w-3 h-3 rounded-full`} style={{ backgroundColor: subject.color }}></div>
                      <span className="font-medium text-text-primary">{subject.subject}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${getGradeColor(subject.grade)}`}>
                        {subject.letter}
                      </span>
                      <span className="text-sm font-medium text-text-primary">
                        {subject.grade.toFixed(1)}
                      </span>
                    </div>
                  </div>
                  <div className="w-full bg-secondary-200 rounded-full h-2">
                    <div
                      className="h-2 rounded-full transition-all duration-300"
                      style={{
                        width: `${getProgressPercentage(subject.grade)}%`,
                        backgroundColor: subject.color
                      }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>

            {/* Grade Distribution Chart */}
            <div className="mt-6">
              <h4 className="text-sm font-medium text-text-primary mb-3">Grade Distribution</h4>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={currentGradesData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                    <XAxis 
                      dataKey="subject" 
                      tick={{ fontSize: 12, fill: '#64748B' }}
                      axisLine={{ stroke: '#E2E8F0' }}
                    />
                    <YAxis 
                      domain={[0, 4]}
                      tick={{ fontSize: 12, fill: '#64748B' }}
                      axisLine={{ stroke: '#E2E8F0' }}
                    />
                    <Tooltip 
                      contentStyle={{
                        backgroundColor: '#FFFFFF',
                        border: '1px solid #E2E8F0',
                        borderRadius: '8px',
                        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)'
                      }}
                    />
                    <Bar dataKey="grade" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        ) : (
          <div>
            <h4 className="text-sm font-medium text-text-primary mb-3">Grade Trends Over Time</h4>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={gradeTrendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                  <XAxis 
                    dataKey="month" 
                    tick={{ fontSize: 12, fill: '#64748B' }}
                    axisLine={{ stroke: '#E2E8F0' }}
                  />
                  <YAxis 
                    domain={[2.5, 4.0]}
                    tick={{ fontSize: 12, fill: '#64748B' }}
                    axisLine={{ stroke: '#E2E8F0' }}
                  />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: '#FFFFFF',
                      border: '1px solid #E2E8F0',
                      borderRadius: '8px',
                      boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)'
                    }}
                  />
                  <Line type="monotone" dataKey="Mathematics" stroke="#3B82F6" strokeWidth={2} dot={{ r: 4 }} />
                  <Line type="monotone" dataKey="Science" stroke="#10B981" strokeWidth={2} dot={{ r: 4 }} />
                  <Line type="monotone" dataKey="English" stroke="#F59E0B" strokeWidth={2} dot={{ r: 4 }} />
                  <Line type="monotone" dataKey="History" stroke="#EF4444" strokeWidth={2} dot={{ r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Legend */}
            <div className="flex flex-wrap items-center justify-center gap-4 mt-4">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-primary rounded-full"></div>
                <span className="text-sm text-text-secondary">Mathematics</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-success rounded-full"></div>
                <span className="text-sm text-text-secondary">Science</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-accent rounded-full"></div>
                <span className="text-sm text-text-secondary">English</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-error rounded-full"></div>
                <span className="text-sm text-text-secondary">History</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default GradeTracking;