import React, { useState } from 'react';
import Icon from 'components/AppIcon';

const CommunicationHub = ({ messages }) => {
  const [expandedMessage, setExpandedMessage] = useState(null);
  const [replyText, setReplyText] = useState('');
  const [showReplyForm, setShowReplyForm] = useState(null);

  const toggleMessage = (messageId) => {
    setExpandedMessage(expandedMessage === messageId ? null : messageId);
    setShowReplyForm(null);
  };

  const handleReply = (messageId) => {
    setShowReplyForm(showReplyForm === messageId ? null : messageId);
    setReplyText('');
  };

  const submitReply = (messageId) => {
    // Mock reply submission
    console.log('Reply submitted for message:', messageId, 'Content:', replyText);
    setReplyText('');
    setShowReplyForm(null);
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'border-l-error bg-error-50';
      case 'normal': return 'border-l-primary bg-primary-50';
      default: return 'border-l-secondary bg-secondary-50';
    }
  };

  return (
    <div className="bg-surface rounded-lg border border-border">
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-heading font-semibold text-text-primary flex items-center space-x-2">
            <Icon name="MessageSquare" size={20} />
            <span>Teacher Communications</span>
          </h2>
          <button className="bg-primary hover:bg-primary-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-micro flex items-center space-x-2">
            <Icon name="Plus" size={16} />
            <span>New Message</span>
          </button>
        </div>
      </div>

      <div className="p-6">
        {messages.length === 0 ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Icon name="MessageSquare" size={32} className="text-text-secondary" />
            </div>
            <h3 className="text-lg font-medium text-text-primary mb-2">No Messages Yet</h3>
            <p className="text-text-secondary">
              Teacher communications will appear here when available.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`border-l-4 rounded-lg ${getPriorityColor(message.priority)}`}
              >
                <div className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center">
                        <span className="text-sm font-medium text-primary">
                          {message.teacher.split(' ').map(n => n[0]).join('')}
                        </span>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-text-primary">
                          {message.teacher}
                        </h4>
                        <p className="text-xs text-text-secondary">
                          {message.student} • {new Date(message.date).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {message.priority === 'high' && (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-error text-white">
                          Urgent
                        </span>
                      )}
                      {!message.replied && (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-accent text-white">
                          New
                        </span>
                      )}
                      <button
                        onClick={() => toggleMessage(message.id)}
                        className="p-1 text-text-secondary hover:text-primary transition-micro"
                      >
                        <Icon 
                          name={expandedMessage === message.id ? "ChevronUp" : "ChevronDown"} 
                          size={16} 
                        />
                      </button>
                    </div>
                  </div>

                  <h3 className="text-sm font-medium text-text-primary mb-2">
                    {message.subject}
                  </h3>

                  {expandedMessage === message.id ? (
                    <div>
                      <div className="bg-surface p-4 rounded-lg mb-4">
                        <p className="text-sm text-text-primary whitespace-pre-line">
                          {message.message}
                        </p>
                      </div>

                      <div className="flex items-center space-x-3">
                        <button
                          onClick={() => handleReply(message.id)}
                          className="flex items-center space-x-2 px-4 py-2 bg-primary hover:bg-primary-700 text-white rounded-lg text-sm font-medium transition-micro"
                        >
                          <Icon name="Reply" size={16} />
                          <span>Reply</span>
                        </button>
                        <button className="flex items-center space-x-2 px-4 py-2 bg-secondary-100 hover:bg-secondary-200 text-text-primary rounded-lg text-sm font-medium transition-micro">
                          <Icon name="Calendar" size={16} />
                          <span>Schedule Meeting</span>
                        </button>
                        <button className="flex items-center space-x-2 px-4 py-2 text-text-secondary hover:text-text-primary text-sm font-medium transition-micro">
                          <Icon name="Phone" size={16} />
                          <span>Call</span>
                        </button>
                      </div>

                      {showReplyForm === message.id && (
                        <div className="mt-4 p-4 bg-secondary-50 rounded-lg">
                          <h4 className="text-sm font-medium text-text-primary mb-3">
                            Reply to {message.teacher}
                          </h4>
                          <textarea
                            value={replyText}
                            onChange={(e) => setReplyText(e.target.value)}
                            placeholder="Type your message here..."
                            className="w-full p-3 border border-border rounded-lg resize-none focus:ring-2 focus:ring-primary focus:border-transparent"
                            rows={4}
                          />
                          <div className="flex items-center justify-end space-x-3 mt-3">
                            <button
                              onClick={() => setShowReplyForm(null)}
                              className="px-4 py-2 text-text-secondary hover:text-text-primary text-sm font-medium transition-micro"
                            >
                              Cancel
                            </button>
                            <button
                              onClick={() => submitReply(message.id)}
                              disabled={!replyText.trim()}
                              className="px-4 py-2 bg-primary hover:bg-primary-700 disabled:bg-secondary-300 text-white rounded-lg text-sm font-medium transition-micro flex items-center space-x-2"
                            >
                              <Icon name="Send" size={16} />
                              <span>Send Reply</span>
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    <p className="text-sm text-text-secondary line-clamp-2">
                      {message.message}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default CommunicationHub;