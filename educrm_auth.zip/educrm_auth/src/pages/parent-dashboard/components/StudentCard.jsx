import React, { useState } from 'react';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const StudentCard = ({ student }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const getGradeColor = (grade) => {
    if (grade.startsWith('A')) return 'text-success bg-success-50';
    if (grade.startsWith('B')) return 'text-primary bg-primary-50';
    if (grade.startsWith('C')) return 'text-accent bg-accent-50';
    return 'text-error bg-error-50';
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'text-error bg-error-50 border-error-200';
      case 'normal': return 'text-primary bg-primary-50 border-primary-200';
      default: return 'text-text-secondary bg-secondary-50 border-secondary-200';
    }
  };

  return (
    <div className="bg-surface rounded-lg border border-border overflow-hidden">
      {/* Student Header */}
      <div className="p-6">
        <div className="flex items-center space-x-4 mb-4">
          <div className="relative">
            <Image
              src={student.photo}
              alt={student.name}
              className="w-16 h-16 rounded-full object-cover"
            />
            <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-success rounded-full border-2 border-surface flex items-center justify-center">
              <Icon name="Check" size={12} color="white" />
            </div>
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-heading font-semibold text-text-primary">
              {student.name}
            </h3>
            <p className="text-text-secondary text-sm">{student.grade}</p>
            <div className="flex items-center space-x-4 mt-2">
              <div className="flex items-center space-x-1">
                <Icon name="Award" size={14} className="text-accent" />
                <span className="text-sm font-medium text-text-primary">
                  GPA: {student.currentGPA}
                </span>
              </div>
              <div className="flex items-center space-x-1">
                <Icon name="Calendar" size={14} className="text-primary" />
                <span className="text-sm text-text-secondary">
                  Next Conference: {student.nextParentTeacher}
                </span>
              </div>
            </div>
          </div>
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-2 text-text-secondary hover:text-primary hover:bg-secondary-50 rounded-lg transition-micro"
          >
            <Icon name={isExpanded ? "ChevronUp" : "ChevronDown"} size={20} />
          </button>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div className="text-center p-3 bg-success-50 rounded-lg">
            <div className="text-lg font-semibold text-success">{student.attendance.present}</div>
            <div className="text-xs text-success-600">Present</div>
          </div>
          <div className="text-center p-3 bg-error-50 rounded-lg">
            <div className="text-lg font-semibold text-error">{student.attendance.absent}</div>
            <div className="text-xs text-error-600">Absent</div>
          </div>
          <div className="text-center p-3 bg-accent-50 rounded-lg">
            <div className="text-lg font-semibold text-accent">{student.attendance.late}</div>
            <div className="text-xs text-accent-600">Late</div>
          </div>
        </div>

        {/* Recent Grades Preview */}
        <div className="mb-4">
          <h4 className="text-sm font-medium text-text-primary mb-2">Recent Grades</h4>
          <div className="flex flex-wrap gap-2">
            {student.recentGrades.slice(0, 3).map((grade, index) => (
              <div
                key={index}
                className={`px-3 py-1 rounded-full text-xs font-medium ${getGradeColor(grade.grade)}`}
              >
                {grade.subject}: {grade.grade}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Expanded Content */}
      {isExpanded && (
        <div className="border-t border-border p-6 bg-secondary-50">
          {/* Upcoming Assignments */}
          <div className="mb-6">
            <h4 className="text-sm font-medium text-text-primary mb-3 flex items-center space-x-2">
              <Icon name="FileText" size={16} />
              <span>Upcoming Assignments</span>
            </h4>
            <div className="space-y-2">
              {student.upcomingAssignments.map((assignment, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-surface rounded-lg">
                  <div>
                    <p className="text-sm font-medium text-text-primary">{assignment.title}</p>
                    <p className="text-xs text-text-secondary">{assignment.subject}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-text-secondary">Due</p>
                    <p className="text-sm font-medium text-accent">
                      {new Date(assignment.dueDate).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Teacher Messages */}
          <div>
            <h4 className="text-sm font-medium text-text-primary mb-3 flex items-center space-x-2">
              <Icon name="MessageSquare" size={16} />
              <span>Recent Teacher Messages</span>
            </h4>
            <div className="space-y-3">
              {student.teacherMessages.map((message, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-lg border ${getPriorityColor(message.priority)}`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-medium">{message.teacher}</span>
                      <span className="text-xs text-text-secondary">•</span>
                      <span className="text-xs text-text-secondary">{message.subject}</span>
                    </div>
                    <span className="text-xs text-text-secondary">
                      {new Date(message.date).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-sm text-text-primary">{message.message}</p>
                  <div className="mt-3 flex items-center space-x-2">
                    <button className="text-xs text-primary hover:text-primary-700 font-medium transition-micro">
                      Reply
                    </button>
                    <button className="text-xs text-text-secondary hover:text-text-primary transition-micro">
                      Schedule Meeting
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StudentCard;