import React, { useState } from 'react';
import Icon from 'components/AppIcon';

const QuickActions = () => {
  const [showExcuseForm, setShowExcuseForm] = useState(false);
  const [showPermissionForm, setShowPermissionForm] = useState(false);
  const [showContactForm, setShowContactForm] = useState(false);

  const quickActions = [
    {
      id: 'excuse',
      title: 'Submit Excuse',
      description: 'Report absence or tardiness',
      icon: 'FileText',
      color: 'bg-primary text-white',
      action: () => setShowExcuseForm(true)
    },
    {
      id: 'permission',
      title: 'Permission Slip',
      description: 'Approve field trips & activities',
      icon: 'CheckSquare',
      color: 'bg-success text-white',
      action: () => setShowPermissionForm(true)
    },
    {
      id: 'contact',
      title: 'Update Contact',
      description: 'Emergency contact info',
      icon: 'Phone',
      color: 'bg-accent text-white',
      action: () => setShowContactForm(true)
    },
    {
      id: 'schedule',
      title: 'Schedule Meeting',
      description: 'Book parent-teacher conference',
      icon: 'Calendar',
      color: 'bg-secondary text-white',
      action: () => console.log('Schedule meeting')
    }
  ];

  const ExcuseForm = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-1010">
      <div className="bg-surface rounded-lg max-w-md w-full p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-heading font-semibold text-text-primary">
            Submit Excuse
          </h3>
          <button
            onClick={() => setShowExcuseForm(false)}
            className="p-1 text-text-secondary hover:text-text-primary transition-micro"
          >
            <Icon name="X" size={20} />
          </button>
        </div>
        <form className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-text-primary mb-2">
              Student
            </label>
            <select className="w-full p-3 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent">
              <option>Emma Johnson</option>
              <option>Alex Johnson</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-text-primary mb-2">
              Date
            </label>
            <input
              type="date"
              className="w-full p-3 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-text-primary mb-2">
              Reason
            </label>
            <select className="w-full p-3 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent">
              <option>Illness</option>
              <option>Medical Appointment</option>
              <option>Family Emergency</option>
              <option>Other</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-text-primary mb-2">
              Additional Notes
            </label>
            <textarea
              className="w-full p-3 border border-border rounded-lg resize-none focus:ring-2 focus:ring-primary focus:border-transparent"
              rows={3}
              placeholder="Optional additional details..."
            />
          </div>
          <div className="flex items-center space-x-3 pt-4">
            <button
              type="button"
              onClick={() => setShowExcuseForm(false)}
              className="flex-1 px-4 py-2 border border-border text-text-secondary hover:text-text-primary rounded-lg transition-micro"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-primary hover:bg-primary-700 text-white rounded-lg transition-micro"
            >
              Submit
            </button>
          </div>
        </form>
      </div>
    </div>
  );

  return (
    <>
      <div className="bg-surface rounded-lg border border-border p-6">
        <h3 className="text-lg font-heading font-semibold text-text-primary mb-4">
          Quick Actions
        </h3>
        <div className="grid grid-cols-2 gap-3">
          {quickActions.map((action) => (
            <button
              key={action.id}
              onClick={action.action}
              className="p-4 rounded-lg border border-border hover:border-primary hover:shadow-sm transition-micro text-left group"
            >
              <div className={`w-10 h-10 ${action.color} rounded-lg flex items-center justify-center mb-3 group-hover:scale-105 transition-transform`}>
                <Icon name={action.icon} size={20} />
              </div>
              <h4 className="text-sm font-medium text-text-primary mb-1">
                {action.title}
              </h4>
              <p className="text-xs text-text-secondary">
                {action.description}
              </p>
            </button>
          ))}
        </div>
      </div>

      {showExcuseForm && <ExcuseForm />}
    </>
  );
};

export default QuickActions;