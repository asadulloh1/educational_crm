import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from 'components/AppIcon';
import AuthenticationNav from 'components/ui/AuthenticationNav';

const LoginScreen = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    role: 'student',
    email: '',
    password: '',
    rememberMe: false
  });
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [failedAttempts, setFailedAttempts] = useState(0);

  // Mock credentials for different roles
  const mockCredentials = {
    'owner-admin': { email: 'admin@educrm.com', password: 'admin123' },
    'teacher': { email: 'teacher@educrm.com', password: 'teacher123' },
    'student': { email: 'student@educrm.com', password: 'student123' },
    'parent': { email: 'parent@educrm.com', password: 'parent123' }
  };

  const roleOptions = [
    { value: 'owner-admin', label: 'Owner/Administrator', icon: 'Shield' },
    { value: 'teacher', label: 'Teacher', icon: 'GraduationCap' },
    { value: 'student', label: 'Student', icon: 'BookOpen' },
    { value: 'parent', label: 'Parent/Guardian', icon: 'Heart' }
  ];

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    
    // Clear errors when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData.password.trim()) {
      newErrors.password = 'Password is required';
    } else if (formData.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsLoading(true);

    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    const roleCredentials = mockCredentials[formData.role];
    
    if (formData.email === roleCredentials.email && formData.password === roleCredentials.password) {
      // Successful login
      setFailedAttempts(0);
      
      // Navigate to role-specific dashboard
      const dashboardRoutes = {
        'owner-admin': '/owner-admin-dashboard',
        'teacher': '/teacher-dashboard',
        'student': '/student-dashboard',
        'parent': '/parent-dashboard'
      };
      
      navigate(dashboardRoutes[formData.role]);
    } else {
      // Failed login
      const newFailedAttempts = failedAttempts + 1;
      setFailedAttempts(newFailedAttempts);
      
      let errorMessage = 'Invalid email or password';
      if (newFailedAttempts >= 3) {
        errorMessage = 'Account will be locked after 5 failed attempts. Please try again.';
      } else if (newFailedAttempts >= 5) {
        errorMessage = 'Account has been temporarily locked. Please contact support.';
      }
      
      setErrors({ 
        submit: errorMessage,
        credentials: `Try: ${roleCredentials.email} / ${roleCredentials.password}`
      });
    }

    setIsLoading(false);
  };

  const getPlaceholderText = (role) => {
    const placeholders = {
      'owner-admin': 'admin@institution.edu',
      'teacher': 'teacher@institution.edu',
      'student': 'student@institution.edu',
      'parent': 'parent@institution.edu'
    };
    return placeholders[role] || 'Enter your email';
  };

  return (
    <div className="min-h-screen bg-background">
      <AuthenticationNav />
      
      <div className="flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-md">
          {/* Login Card */}
          <div className="bg-surface rounded-xl shadow-card border border-border p-8">
            {/* Header */}
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-primary rounded-xl flex items-center justify-center mx-auto mb-4">
                <Icon name="GraduationCap" size={32} color="white" />
              </div>
              <h1 className="text-2xl font-heading font-bold text-text-primary mb-2">
                Welcome Back
              </h1>
              <p className="text-text-secondary">
                Sign in to your EduCRM account
              </p>
            </div>

            {/* Login Form */}
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Role Selection */}
              <div>
                <label htmlFor="role" className="block text-sm font-medium text-text-primary mb-2">
                  Select Your Role
                </label>
                <div className="relative">
                  <select
                    id="role"
                    name="role"
                    value={formData.role}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 bg-surface border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary transition-micro appearance-none"
                  >
                    {roleOptions.map(option => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                  <Icon 
                    name="ChevronDown" 
                    size={20} 
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-text-secondary pointer-events-none" 
                  />
                </div>
              </div>

              {/* Email Input */}
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-text-primary mb-2">
                  Email Address
                </label>
                <div className="relative">
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder={getPlaceholderText(formData.role)}
                    className={`w-full px-4 py-3 bg-surface border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary transition-micro pl-12 ${
                      errors.email ? 'border-error' : 'border-border'
                    }`}
                  />
                  <Icon 
                    name="Mail" 
                    size={20} 
                    className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary" 
                  />
                </div>
                {errors.email && (
                  <p className="mt-1 text-sm text-error flex items-center space-x-1">
                    <Icon name="AlertCircle" size={16} />
                    <span>{errors.email}</span>
                  </p>
                )}
              </div>

              {/* Password Input */}
              <div>
                <label htmlFor="password" className="block text-sm font-medium text-text-primary mb-2">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    id="password"
                    name="password"
                    value={formData.password}
                    onChange={handleInputChange}
                    placeholder="Enter your password"
                    className={`w-full px-4 py-3 bg-surface border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary transition-micro pl-12 pr-12 ${
                      errors.password ? 'border-error' : 'border-border'
                    }`}
                  />
                  <Icon 
                    name="Lock" 
                    size={20} 
                    className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary" 
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-text-secondary hover:text-text-primary transition-micro"
                  >
                    <Icon name={showPassword ? 'EyeOff' : 'Eye'} size={20} />
                  </button>
                </div>
                {errors.password && (
                  <p className="mt-1 text-sm text-error flex items-center space-x-1">
                    <Icon name="AlertCircle" size={16} />
                    <span>{errors.password}</span>
                  </p>
                )}
              </div>

              {/* Remember Me & Forgot Password */}
              <div className="flex items-center justify-between">
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    name="rememberMe"
                    checked={formData.rememberMe}
                    onChange={handleInputChange}
                    className="w-4 h-4 text-primary bg-surface border-border rounded focus:ring-primary focus:ring-2"
                  />
                  <span className="text-sm text-text-secondary">Remember me</span>
                </label>
                <button
                  type="button"
                  className="text-sm text-primary hover:text-primary-700 font-medium transition-micro"
                >
                  Forgot password?
                </button>
              </div>

              {/* Error Messages */}
              {errors.submit && (
                <div className="bg-error-50 border border-error-200 rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <Icon name="AlertTriangle" size={16} className="text-error" />
                    <p className="text-sm text-error font-medium">{errors.submit}</p>
                  </div>
                  {errors.credentials && (
                    <p className="text-xs text-text-secondary bg-secondary-50 p-2 rounded font-data">
                      {errors.credentials}
                    </p>
                  )}
                </div>
              )}

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-primary hover:bg-primary-700 disabled:bg-secondary-300 text-white py-3 px-4 rounded-lg font-medium transition-micro flex items-center justify-center space-x-2"
              >
                {isLoading ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Signing In...</span>
                  </>
                ) : (
                  <>
                    <Icon name="LogIn" size={20} />
                    <span>Sign In</span>
                  </>
                )}
              </button>
            </form>

            {/* Footer */}
            <div className="mt-8 text-center">
              <p className="text-sm text-text-secondary">
                Don't have an account?{' '}
                <button
                  onClick={() => navigate('/user-registration-screen')}
                  className="text-primary hover:text-primary-700 font-medium transition-micro"
                >
                  Create Account
                </button>
              </p>
            </div>
          </div>

          {/* Help Section */}
          <div className="mt-6 text-center">
            <div className="bg-secondary-50 rounded-lg p-4">
              <div className="flex items-center justify-center space-x-2 mb-2">
                <Icon name="HelpCircle" size={16} className="text-text-secondary" />
                <span className="text-sm font-medium text-text-secondary">Need Help?</span>
              </div>
              <p className="text-xs text-text-secondary">
                Contact your institution's IT support or email support@educrm.com
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginScreen;