import React, { useState } from 'react';
import Icon from 'components/AppIcon';

const QuickActions = () => {
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isAnnouncementModalOpen, setIsAnnouncementModalOpen] = useState(false);

  const quickActionItems = [
    {
      id: 1,
      title: "Bulk User Import",
      description: "Import multiple users from CSV or Excel file",
      icon: "Upload",
      color: "primary",
      action: () => setIsImportModalOpen(true),
      shortcut: "Ctrl+U"
    },
    {
      id: 2,
      title: "Role Management",
      description: "Assign and modify user roles and permissions",
      icon: "UserCog",
      color: "accent",
      action: () => console.log("Role Management"),
      shortcut: "Ctrl+R"
    },
    {
      id: 3,
      title: "System Announcement",
      description: "Send important notifications to all users",
      icon: "Megaphone",
      color: "success",
      action: () => setIsAnnouncementModalOpen(true),
      shortcut: "Ctrl+A"
    },
    {
      id: 4,
      title: "Generate Reports",
      description: "Create custom reports and analytics",
      icon: "FileBarChart",
      color: "secondary",
      action: () => console.log("Generate Reports"),
      shortcut: "Ctrl+G"
    },
    {
      id: 5,
      title: "Backup System",
      description: "Create system backup and data export",
      icon: "Database",
      color: "warning",
      action: () => console.log("Backup System"),
      shortcut: "Ctrl+B"
    },
    {
      id: 6,
      title: "Security Audit",
      description: "Review security logs and user activities",
      icon: "Shield",
      color: "error",
      action: () => console.log("Security Audit"),
      shortcut: "Ctrl+S"
    }
  ];

  const getColorClasses = (color) => {
    const colorMap = {
      primary: {
        bg: "bg-primary-50 hover:bg-primary-100",
        icon: "text-primary",
        border: "border-primary-200"
      },
      accent: {
        bg: "bg-accent-50 hover:bg-accent-100",
        icon: "text-accent",
        border: "border-accent-200"
      },
      success: {
        bg: "bg-success-50 hover:bg-success-100",
        icon: "text-success",
        border: "border-success-200"
      },
      secondary: {
        bg: "bg-secondary-50 hover:bg-secondary-100",
        icon: "text-secondary-600",
        border: "border-secondary-200"
      },
      warning: {
        bg: "bg-warning-50 hover:bg-warning-100",
        icon: "text-warning-600",
        border: "border-warning-200"
      },
      error: {
        bg: "bg-error-50 hover:bg-error-100",
        icon: "text-error",
        border: "border-error-200"
      }
    };
    return colorMap[color] || colorMap.primary;
  };

  const handleImportSubmit = (e) => {
    e.preventDefault();
    console.log("Processing bulk import...");
    setIsImportModalOpen(false);
  };

  const handleAnnouncementSubmit = (e) => {
    e.preventDefault();
    console.log("Sending announcement...");
    setIsAnnouncementModalOpen(false);
  };

  return (
    <>
      <div className="bg-surface rounded-lg border border-border shadow-card">
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-heading font-semibold text-text-primary">Quick Actions</h2>
              <p className="text-text-secondary text-sm mt-1">Frequently used administrative functions</p>
            </div>
            <div className="flex items-center space-x-2">
              <Icon name="Zap" size={20} className="text-accent" />
              <span className="text-sm text-text-secondary">Keyboard shortcuts enabled</span>
            </div>
          </div>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {quickActionItems.map((item) => {
              const colors = getColorClasses(item.color);
              
              return (
                <button
                  key={item.id}
                  onClick={item.action}
                  className={`p-4 rounded-lg border ${colors.border} ${colors.bg} transition-smooth text-left group`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className={`w-10 h-10 rounded-lg bg-surface flex items-center justify-center ${colors.icon} group-hover:scale-110 transition-transform`}>
                      <Icon name={item.icon} size={20} />
                    </div>
                    <span className="text-xs text-text-secondary bg-secondary-100 px-2 py-1 rounded font-mono">
                      {item.shortcut}
                    </span>
                  </div>
                  
                  <h3 className="font-medium text-text-primary mb-2 group-hover:text-primary transition-micro">
                    {item.title}
                  </h3>
                  <p className="text-sm text-text-secondary">
                    {item.description}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        <div className="p-4 bg-secondary-50 border-t border-border">
          <div className="flex items-center justify-between text-sm">
            <span className="text-text-secondary">Need help with administrative tasks?</span>
            <button className="text-primary hover:text-primary-700 font-medium transition-micro flex items-center space-x-1">
              <Icon name="HelpCircle" size={16} />
              <span>View Documentation</span>
            </button>
          </div>
        </div>
      </div>

      {/* Bulk Import Modal */}
      {isImportModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-1000">
          <div className="bg-surface rounded-lg shadow-modal max-w-md w-full mx-4">
            <div className="p-6 border-b border-border">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-heading font-semibold text-text-primary">Bulk User Import</h3>
                <button
                  onClick={() => setIsImportModalOpen(false)}
                  className="p-1 text-text-secondary hover:text-text-primary transition-micro"
                >
                  <Icon name="X" size={20} />
                </button>
              </div>
            </div>
            
            <form onSubmit={handleImportSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Select File
                </label>
                <input
                  type="file"
                  accept=".csv,.xlsx,.xls"
                  className="w-full p-3 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                />
                <p className="text-xs text-text-secondary mt-1">
                  Supported formats: CSV, Excel (.xlsx, .xls)
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  User Role
                </label>
                <select className="w-full p-3 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent">
                  <option value="student">Student</option>
                  <option value="teacher">Teacher</option>
                  <option value="parent">Parent</option>
                </select>
              </div>
              
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="sendWelcome" className="rounded" />
                <label htmlFor="sendWelcome" className="text-sm text-text-primary">
                  Send welcome emails to new users
                </label>
              </div>
              
              <div className="flex space-x-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-primary hover:bg-primary-700 text-white py-2 px-4 rounded-lg font-medium transition-micro"
                >
                  Import Users
                </button>
                <button
                  type="button"
                  onClick={() => setIsImportModalOpen(false)}
                  className="flex-1 bg-secondary-100 hover:bg-secondary-200 text-text-primary py-2 px-4 rounded-lg font-medium transition-micro"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Announcement Modal */}
      {isAnnouncementModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-1000">
          <div className="bg-surface rounded-lg shadow-modal max-w-lg w-full mx-4">
            <div className="p-6 border-b border-border">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-heading font-semibold text-text-primary">System Announcement</h3>
                <button
                  onClick={() => setIsAnnouncementModalOpen(false)}
                  className="p-1 text-text-secondary hover:text-text-primary transition-micro"
                >
                  <Icon name="X" size={20} />
                </button>
              </div>
            </div>
            
            <form onSubmit={handleAnnouncementSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Announcement Title
                </label>
                <input
                  type="text"
                  placeholder="Enter announcement title"
                  className="w-full p-3 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Message
                </label>
                <textarea
                  rows={4}
                  placeholder="Enter your announcement message"
                  className="w-full p-3 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
                ></textarea>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Send To
                </label>
                <select className="w-full p-3 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent">
                  <option value="all">All Users</option>
                  <option value="teachers">Teachers Only</option>
                  <option value="students">Students Only</option>
                  <option value="parents">Parents Only</option>
                </select>
              </div>
              
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="urgent" className="rounded" />
                <label htmlFor="urgent" className="text-sm text-text-primary">
                  Mark as urgent
                </label>
              </div>
              
              <div className="flex space-x-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-primary hover:bg-primary-700 text-white py-2 px-4 rounded-lg font-medium transition-micro"
                >
                  Send Announcement
                </button>
                <button
                  type="button"
                  onClick={() => setIsAnnouncementModalOpen(false)}
                  className="flex-1 bg-secondary-100 hover:bg-secondary-200 text-text-primary py-2 px-4 rounded-lg font-medium transition-micro"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};

export default QuickActions;