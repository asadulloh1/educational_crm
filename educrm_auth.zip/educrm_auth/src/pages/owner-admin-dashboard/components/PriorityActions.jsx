import React from 'react';
import Icon from 'components/AppIcon';

const PriorityActions = () => {
  const priorityItems = [
    {
      id: 1,
      type: "approval",
      title: "Pending User Approvals",
      description: "15 teacher registration requests awaiting approval",
      count: 15,
      urgency: "high",
      icon: "UserCheck",
      action: "Review Applications",
      dueDate: "Due Today"
    },
    {
      id: 2,
      type: "verification",
      title: "Account Verification Requests",
      description: "23 parent accounts need email verification follow-up",
      count: 23,
      urgency: "medium",
      icon: "Mail",
      action: "Send Reminders",
      dueDate: "2 days overdue"
    },
    {
      id: 3,
      type: "alert",
      title: "System Security Alerts",
      description: "3 failed login attempts detected from suspicious IPs",
      count: 3,
      urgency: "high",
      icon: "AlertTriangle",
      action: "Review Security",
      dueDate: "Immediate"
    },
    {
      id: 4,
      type: "maintenance",
      title: "Scheduled Maintenance",
      description: "Database optimization scheduled for this weekend",
      count: 1,
      urgency: "low",
      icon: "Settings",
      action: "Prepare Notice",
      dueDate: "In 3 days"
    },
    {
      id: 5,
      type: "report",
      title: "Monthly Reports Due",
      description: "Generate and send monthly usage reports to stakeholders",
      count: 4,
      urgency: "medium",
      icon: "FileBarChart",
      action: "Generate Reports",
      dueDate: "Due in 5 days"
    }
  ];

  const getUrgencyStyles = (urgency) => {
    const styles = {
      high: {
        border: "border-l-error",
        bg: "bg-error-50",
        badge: "bg-error text-white",
        icon: "text-error"
      },
      medium: {
        border: "border-l-accent",
        bg: "bg-accent-50",
        badge: "bg-accent text-white",
        icon: "text-accent"
      },
      low: {
        border: "border-l-success",
        bg: "bg-success-50",
        badge: "bg-success text-white",
        icon: "text-success"
      }
    };
    return styles[urgency] || styles.medium;
  };

  const handleActionClick = (item) => {
    console.log(`Handling action for: ${item.title}`);
    // Navigate to specific action page or open modal
  };

  return (
    <div className="bg-surface rounded-lg border border-border shadow-card">
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-heading font-semibold text-text-primary">Priority Actions</h2>
            <p className="text-text-secondary text-sm mt-1">Items requiring immediate attention</p>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-text-secondary">Auto-refresh</span>
            <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
          </div>
        </div>
      </div>

      <div className="divide-y divide-border">
        {priorityItems.map((item) => {
          const urgencyStyles = getUrgencyStyles(item.urgency);
          
          return (
            <div key={item.id} className={`p-6 border-l-4 ${urgencyStyles.border} hover:${urgencyStyles.bg} transition-micro`}>
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4 flex-1">
                  <div className={`w-10 h-10 bg-secondary-100 rounded-lg flex items-center justify-center ${urgencyStyles.icon}`}>
                    <Icon name={item.icon} size={20} />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="font-medium text-text-primary">{item.title}</h3>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${urgencyStyles.badge}`}>
                        {item.count}
                      </span>
                    </div>
                    <p className="text-text-secondary text-sm mb-3">{item.description}</p>
                    <div className="flex items-center space-x-4 text-xs text-text-secondary">
                      <span className="flex items-center space-x-1">
                        <Icon name="Clock" size={12} />
                        <span>{item.dueDate}</span>
                      </span>
                      <span className="flex items-center space-x-1">
                        <Icon name="Flag" size={12} />
                        <span className="capitalize">{item.urgency} Priority</span>
                      </span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => handleActionClick(item)}
                  className="ml-4 px-4 py-2 bg-primary hover:bg-primary-700 text-white text-sm font-medium rounded-lg transition-micro flex items-center space-x-2"
                >
                  <span>{item.action}</span>
                  <Icon name="ArrowRight" size={14} />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      <div className="p-4 bg-secondary-50 border-t border-border">
        <button className="w-full text-center text-sm text-primary hover:text-primary-700 font-medium transition-micro">
          View All Priority Items (12 more)
        </button>
      </div>
    </div>
  );
};

export default PriorityActions;