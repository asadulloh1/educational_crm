import React, { useState, useEffect } from 'react';
import Icon from 'components/AppIcon';
import { format, startOfMonth, endOfMonth, startOfWeek, endOfWeek, addDays, isSameMonth, isSameDay, addMonths, subMonths, addWeeks, subWeeks } from 'date-fns';

const InteractiveCalendar = ({ isFullScreen = false, onToggleFullScreen }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [view, setView] = useState('month'); // 'month', 'week', 'day'
  const [events, setEvents] = useState([
    {
      id: 1,
      title: 'Parent-Teacher Meeting',
      date: new Date(2024, 11, 15, 10, 0),
      type: 'meeting',
      color: 'blue'
    },
    {
      id: 2,
      title: 'Math Exam',
      date: new Date(2024, 11, 18, 9, 0),
      type: 'exam',
      color: 'red'
    },
    {
      id: 3,
      title: 'Science Fair',
      date: new Date(2024, 11, 22, 14, 0),
      type: 'event',
      color: 'green'
    },
    {
      id: 4,
      title: 'Staff Meeting',
      date: new Date(2024, 11, 25, 11, 0),
      type: 'meeting',
      color: 'blue'
    }
  ]);
  const [showEventModal, setShowEventModal] = useState(false);
  const [selectedEventDate, setSelectedEventDate] = useState(null);
  const [newEvent, setNewEvent] = useState({
    title: '',
    type: 'meeting',
    time: '09:00'
  });

  const eventColors = {
    meeting: 'bg-blue-500 text-white',
    exam: 'bg-red-500 text-white',
    event: 'bg-green-500 text-white'
  };

  const eventTextColors = {
    meeting: 'text-blue-600',
    exam: 'text-red-600',
    event: 'text-green-600'
  };

  // Navigation functions
  const navigatePrevious = () => {
    if (view === 'month') {
      setCurrentDate(subMonths(currentDate, 1));
    } else if (view === 'week') {
      setCurrentDate(subWeeks(currentDate, 1));
    } else {
      setCurrentDate(addDays(currentDate, -1));
    }
  };

  const navigateNext = () => {
    if (view === 'month') {
      setCurrentDate(addMonths(currentDate, 1));
    } else if (view === 'week') {
      setCurrentDate(addWeeks(currentDate, 1));
    } else {
      setCurrentDate(addDays(currentDate, 1));
    }
  };

  const goToToday = () => {
    setCurrentDate(new Date());
    setSelectedDate(new Date());
  };

  // Get events for a specific date
  const getEventsForDate = (date) => {
    return events.filter(event => isSameDay(event.date, date));
  };

  // Handle date click
  const handleDateClick = (date) => {
    setSelectedDate(date);
    setSelectedEventDate(date);
    setShowEventModal(true);
  };

  // Handle event creation
  const handleCreateEvent = () => {
    if (newEvent.title.trim() && selectedEventDate) {
      const [hours, minutes] = newEvent.time.split(':');
      const eventDate = new Date(selectedEventDate);
      eventDate.setHours(parseInt(hours), parseInt(minutes));

      const event = {
        id: Date.now(),
        title: newEvent.title,
        date: eventDate,
        type: newEvent.type,
        color: newEvent.type
      };

      setEvents([...events, event]);
      setNewEvent({ title: '', type: 'meeting', time: '09:00' });
      setShowEventModal(false);
    }
  };

  // Render month view
  const renderMonthView = () => {
    const monthStart = startOfMonth(currentDate);
    const monthEnd = endOfMonth(monthStart);
    const startDate = startOfWeek(monthStart);
    const endDate = endOfWeek(monthEnd);

    const dateFormat = "d";
    const rows = [];
    let days = [];
    let day = startDate;

    while (day <= endDate) {
      for (let i = 0; i < 7; i++) {
        const cloneDay = day;
        const dayEvents = getEventsForDate(day);
        
        days.push(
          <div
            key={day}
            className={`min-h-[100px] p-2 border border-border cursor-pointer hover:bg-secondary-50 transition-micro ${
              !isSameMonth(day, monthStart) ? 'text-text-secondary bg-secondary-25' : ''
            } ${isSameDay(day, selectedDate) ? 'bg-primary-50 border-primary' : ''}`}
            onClick={() => handleDateClick(cloneDay)}
          >
            <div className="flex items-center justify-between mb-1">
              <span className={`text-sm font-medium ${
                isSameDay(day, new Date()) ? 'bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center' : ''
              }`}>
                {format(day, dateFormat)}
              </span>
            </div>
            <div className="space-y-1">
              {dayEvents.slice(0, 2).map(event => (
                <div
                  key={event.id}
                  className={`text-xs px-2 py-1 rounded truncate ${eventColors[event.type]}`}
                  title={event.title}
                >
                  {event.title}
                </div>
              ))}
              {dayEvents.length > 2 && (
                <div className="text-xs text-text-secondary">
                  +{dayEvents.length - 2} more
                </div>
              )}
            </div>
          </div>
        );
        day = addDays(day, 1);
      }
      rows.push(
        <div key={day} className="grid grid-cols-7">
          {days}
        </div>
      );
      days = [];
    }

    return (
      <div>
        {/* Week days header */}
        <div className="grid grid-cols-7 border-b border-border">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
            <div key={day} className="p-3 text-center text-sm font-medium text-text-secondary bg-secondary-25">
              {day}
            </div>
          ))}
        </div>
        {rows}
      </div>
    );
  };

  // Render week view
  const renderWeekView = () => {
    const weekStart = startOfWeek(currentDate);
    const weekDays = [];
    
    for (let i = 0; i < 7; i++) {
      const day = addDays(weekStart, i);
      const dayEvents = getEventsForDate(day);
      
      weekDays.push(
        <div key={day} className="border-r border-border last:border-r-0">
          <div className={`p-3 text-center border-b border-border ${
            isSameDay(day, new Date()) ? 'bg-primary text-white' : 'bg-secondary-25'
          }`}>
            <div className="text-sm font-medium">{format(day, 'EEE')}</div>
            <div className="text-lg font-bold">{format(day, 'd')}</div>
          </div>
          <div className="p-2 min-h-[400px] space-y-2">
            {dayEvents.map(event => (
              <div
                key={event.id}
                className={`p-2 rounded text-sm ${eventColors[event.type]} cursor-pointer`}
                onClick={() => handleDateClick(day)}
              >
                <div className="font-medium">{format(event.date, 'HH:mm')}</div>
                <div>{event.title}</div>
              </div>
            ))}
            <button
              onClick={() => handleDateClick(day)}
              className="w-full p-2 border-2 border-dashed border-border rounded text-sm text-text-secondary hover:border-primary hover:text-primary transition-micro"
            >
              + Add Event
            </button>
          </div>
        </div>
      );
    }

    return (
      <div className="grid grid-cols-7 border border-border rounded-lg overflow-hidden">
        {weekDays}
      </div>
    );
  };

  // Render day view
  const renderDayView = () => {
    const dayEvents = getEventsForDate(currentDate);
    const hours = Array.from({ length: 24 }, (_, i) => i);

    return (
      <div className="border border-border rounded-lg overflow-hidden">
        <div className={`p-4 text-center border-b border-border ${
          isSameDay(currentDate, new Date()) ? 'bg-primary text-white' : 'bg-secondary-25'
        }`}>
          <div className="text-lg font-bold">{format(currentDate, 'EEEE, MMMM d, yyyy')}</div>
        </div>
        <div className="max-h-[500px] overflow-y-auto">
          {hours.map(hour => {
            const hourEvents = dayEvents.filter(event => event.date.getHours() === hour);
            return (
              <div key={hour} className="flex border-b border-border min-h-[60px]">
                <div className="w-20 p-3 bg-secondary-25 border-r border-border text-sm text-text-secondary">
                  {format(new Date().setHours(hour, 0), 'HH:mm')}
                </div>
                <div className="flex-1 p-2 space-y-1">
                  {hourEvents.map(event => (
                    <div
                      key={event.id}
                      className={`p-2 rounded text-sm ${eventColors[event.type]} cursor-pointer`}
                    >
                      <div className="font-medium">{event.title}</div>
                      <div className="text-xs opacity-90">{format(event.date, 'HH:mm')}</div>
                    </div>
                  ))}
                  {hourEvents.length === 0 && (
                    <button
                      onClick={() => {
                        const eventDate = new Date(currentDate);
                        eventDate.setHours(hour, 0);
                        handleDateClick(eventDate);
                      }}
                      className="w-full h-full min-h-[40px] border-2 border-dashed border-transparent hover:border-primary rounded text-sm text-text-secondary hover:text-primary transition-micro opacity-0 hover:opacity-100"
                    >
                      + Add Event
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const getViewTitle = () => {
    if (view === 'month') {
      return format(currentDate, 'MMMM yyyy');
    } else if (view === 'week') {
      const weekStart = startOfWeek(currentDate);
      const weekEnd = endOfWeek(currentDate);
      return `${format(weekStart, 'MMM d')} - ${format(weekEnd, 'MMM d, yyyy')}`;
    } else {
      return format(currentDate, 'EEEE, MMMM d, yyyy');
    }
  };

  return (
    <div className={`h-full flex flex-col ${isFullScreen ? 'bg-surface' : ''}`}>
      {/* Calendar Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-heading font-semibold text-text-primary">Interactive Calendar</h3>
          <div className="flex items-center space-x-2">
            {isFullScreen && (
              <button
                onClick={onToggleFullScreen}
                className="p-2 text-text-secondary hover:text-primary hover:bg-secondary-50 rounded-lg transition-micro"
                title="Exit Full Screen"
              >
                <Icon name="X" size={16} />
              </button>
            )}
            <button
              onClick={goToToday}
              className="px-3 py-1 text-sm bg-primary text-white rounded-lg hover:bg-primary-600 transition-micro"
            >
              Today
            </button>
          </div>
        </div>

        {/* Navigation and View Controls */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <button
              onClick={navigatePrevious}
              className="p-2 text-text-secondary hover:text-primary hover:bg-secondary-50 rounded-lg transition-micro"
            >
              <Icon name="ChevronLeft" size={16} />
            </button>
            <h4 className={`text-lg font-medium text-text-primary text-center ${isFullScreen ? 'min-w-[250px]' : 'min-w-[200px]'}`}>
              {getViewTitle()}
            </h4>
            <button
              onClick={navigateNext}
              className="p-2 text-text-secondary hover:text-primary hover:bg-secondary-50 rounded-lg transition-micro"
            >
              <Icon name="ChevronRight" size={16} />
            </button>
          </div>

          {/* View Toggle */}
          <div className="flex bg-secondary-100 rounded-lg p-1">
            {['month', 'week', 'day'].map((viewType) => (
              <button
                key={viewType}
                onClick={() => setView(viewType)}
                className={`px-3 py-1 text-sm rounded transition-micro capitalize ${
                  view === viewType
                    ? 'bg-primary text-white' :'text-text-secondary hover:text-text-primary'
                }`}
              >
                {viewType}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Calendar Content */}
      <div className={`flex-1 overflow-hidden ${isFullScreen ? 'p-2' : ''}`}>
        {view === 'month' && renderMonthView()}
        {view === 'week' && renderWeekView()}
        {view === 'day' && renderDayView()}
      </div>

      {/* Event Legend */}
      <div className="p-4 border-t border-border">
        <div className="flex items-center justify-center space-x-6">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-red-500 rounded"></div>
            <span className="text-sm text-text-secondary">Exams</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-blue-500 rounded"></div>
            <span className="text-sm text-text-secondary">Meetings</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded"></div>
            <span className="text-sm text-text-secondary">Events</span>
          </div>
        </div>
      </div>

      {/* Event Modal */}
      {showEventModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-text-primary">
                Add Event - {selectedEventDate && format(selectedEventDate, 'MMM d, yyyy')}
              </h3>
              <button
                onClick={() => setShowEventModal(false)}
                className="p-1 text-text-secondary hover:text-primary rounded-lg transition-micro"
              >
                <Icon name="X" size={20} />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Event Title
                </label>
                <input
                  type="text"
                  value={newEvent.title}
                  onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                  placeholder="Enter event title"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Event Type
                </label>
                <select
                  value={newEvent.type}
                  onChange={(e) => setNewEvent({ ...newEvent, type: e.target.value })}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                >
                  <option value="meeting">Meeting</option>
                  <option value="exam">Exam</option>
                  <option value="event">Event</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-text-primary mb-2">
                  Time
                </label>
                <input
                  type="time"
                  value={newEvent.time}
                  onChange={(e) => setNewEvent({ ...newEvent, time: e.target.value })}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                />
              </div>
            </div>

            <div className="flex space-x-3 mt-6">
              <button
                onClick={() => setShowEventModal(false)}
                className="flex-1 px-4 py-2 text-text-secondary border border-border rounded-lg hover:bg-secondary-50 transition-micro"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateEvent}
                className="flex-1 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-600 transition-micro"
              >
                Add Event
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default InteractiveCalendar;