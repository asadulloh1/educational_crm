import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import Icon from 'components/AppIcon';

const AnalyticsCharts = () => {
  const userEngagementData = [
    { month: 'Jan', students: 1850, teachers: 120, parents: 380, admins: 8 },
    { month: 'Feb', students: 1920, teachers: 125, parents: 395, admins: 8 },
    { month: 'Mar', students: 2100, teachers: 135, parents: 420, admins: 8 },
    { month: 'Apr', students: 2180, teachers: 142, parents: 435, admins: 8 },
    { month: 'May', students: 2234, teachers: 156, parents: 449, admins: 8 },
    { month: 'Jun', students: 2280, teachers: 160, parents: 460, admins: 8 }
  ];

  const loginTrendsData = [
    { day: 'Mon', logins: 1240 },
    { day: 'Tue', logins: 1380 },
    { day: 'Wed', logins: 1520 },
    { day: 'Thu', logins: 1450 },
    { day: 'Fri', logins: 1680 },
    { day: 'Sat', logins: 890 },
    { day: 'Sun', logins: 720 }
  ];

  const roleDistributionData = [
    { name: 'Students', value: 2234, color: '#3B82F6' },
    { name: 'Parents', value: 449, color: '#F59E0B' },
    { name: 'Teachers', value: 156, color: '#10B981' },
    { name: 'Admins', value: 8, color: '#EF4444' }
  ];

  const systemHealthData = [
    { metric: 'CPU Usage', value: 45, status: 'good' },
    { metric: 'Memory', value: 67, status: 'warning' },
    { metric: 'Storage', value: 23, status: 'good' },
    { metric: 'Network', value: 89, status: 'critical' }
  ];

  const getHealthColor = (status) => {
    const colors = {
      good: 'text-success',
      warning: 'text-accent',
      critical: 'text-error'
    };
    return colors[status] || 'text-text-secondary';
  };

  const getHealthBg = (status) => {
    const colors = {
      good: 'bg-success',
      warning: 'bg-accent',
      critical: 'bg-error'
    };
    return colors[status] || 'bg-secondary-300';
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* User Engagement Trends */}
      <div className="bg-surface rounded-lg border border-border shadow-card p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-heading font-semibold text-text-primary">User Growth Trends</h3>
            <p className="text-text-secondary text-sm">Monthly user registration by role</p>
          </div>
          <Icon name="TrendingUp" size={20} className="text-success" />
        </div>
        
        <div className="h-64" aria-label="User Growth Trends Bar Chart">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={userEngagementData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
              <XAxis dataKey="month" stroke="#64748B" fontSize={12} />
              <YAxis stroke="#64748B" fontSize={12} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#FFFFFF', 
                  border: '1px solid #E2E8F0',
                  borderRadius: '8px',
                  fontSize: '12px'
                }}
              />
              <Bar dataKey="students" fill="#3B82F6" name="Students" />
              <Bar dataKey="teachers" fill="#10B981" name="Teachers" />
              <Bar dataKey="parents" fill="#F59E0B" name="Parents" />
              <Bar dataKey="admins" fill="#EF4444" name="Admins" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Login Activity */}
      <div className="bg-surface rounded-lg border border-border shadow-card p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-heading font-semibold text-text-primary">Weekly Login Activity</h3>
            <p className="text-text-secondary text-sm">Daily login patterns this week</p>
          </div>
          <Icon name="Activity" size={20} className="text-primary" />
        </div>
        
        <div className="h-64" aria-label="Weekly Login Activity Line Chart">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={loginTrendsData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
              <XAxis dataKey="day" stroke="#64748B" fontSize={12} />
              <YAxis stroke="#64748B" fontSize={12} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#FFFFFF', 
                  border: '1px solid #E2E8F0',
                  borderRadius: '8px',
                  fontSize: '12px'
                }}
              />
              <Line 
                type="monotone" 
                dataKey="logins" 
                stroke="#3B82F6" 
                strokeWidth={3}
                dot={{ fill: '#3B82F6', strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6, stroke: '#3B82F6', strokeWidth: 2 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Role Distribution */}
      <div className="bg-surface rounded-lg border border-border shadow-card p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-heading font-semibold text-text-primary">User Role Distribution</h3>
            <p className="text-text-secondary text-sm">Current user breakdown by role</p>
          </div>
          <Icon name="PieChart" size={20} className="text-accent" />
        </div>
        
        <div className="flex items-center space-x-6">
          <div className="h-48 w-48" aria-label="User Role Distribution Pie Chart">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={roleDistributionData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={80}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {roleDistributionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#FFFFFF', 
                    border: '1px solid #E2E8F0',
                    borderRadius: '8px',
                    fontSize: '12px'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          
          <div className="flex-1 space-y-3">
            {roleDistributionData.map((item, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: item.color }}
                  ></div>
                  <span className="text-sm text-text-primary">{item.name}</span>
                </div>
                <span className="text-sm font-medium text-text-primary">{item.value.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* System Health */}
      <div className="bg-surface rounded-lg border border-border shadow-card p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-heading font-semibold text-text-primary">System Health</h3>
            <p className="text-text-secondary text-sm">Real-time system performance metrics</p>
          </div>
          <Icon name="Server" size={20} className="text-success" />
        </div>
        
        <div className="space-y-4">
          {systemHealthData.map((item, index) => (
            <div key={index} className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-text-primary">{item.metric}</span>
                <span className={`text-sm font-medium ${getHealthColor(item.status)}`}>
                  {item.value}%
                </span>
              </div>
              <div className="w-full bg-secondary-200 rounded-full h-2">
                <div 
                  className={`h-2 rounded-full transition-all duration-300 ${getHealthBg(item.status)}`}
                  style={{ width: `${item.value}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-6 pt-4 border-t border-border">
          <div className="flex items-center justify-between text-sm">
            <span className="text-text-secondary">Overall System Status</span>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
              <span className="text-success font-medium">Operational</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsCharts;