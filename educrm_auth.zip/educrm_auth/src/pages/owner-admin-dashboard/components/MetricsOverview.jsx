import React from 'react';
import Icon from 'components/AppIcon';

const MetricsOverview = () => {
  const metricsData = [
    {
      id: 1,
      title: "Total Users",
      value: "2,847",
      change: "+12.5%",
      changeType: "increase",
      icon: "Users",
      color: "primary",
      breakdown: [
        { label: "Admins", count: 8 },
        { label: "Teachers", count: 156 },
        { label: "Students", count: 2234 },
        { label: "Parents", count: 449 }
      ]
    },
    {
      id: 2,
      title: "New Registrations",
      value: "89",
      change: "+23.1%",
      changeType: "increase",
      icon: "UserPlus",
      color: "success",
      period: "This Month"
    },
    {
      id: 3,
      title: "Active Sessions",
      value: "1,234",
      change: "-5.2%",
      changeType: "decrease",
      icon: "Activity",
      color: "accent",
      period: "Right Now"
    },
    {
      id: 4,
      title: "System Health",
      value: "99.8%",
      change: "+0.3%",
      changeType: "increase",
      icon: "Shield",
      color: "success",
      period: "Uptime"
    }
  ];

  const getColorClasses = (color) => {
    const colorMap = {
      primary: {
        bg: "bg-primary-50",
        icon: "text-primary",
        border: "border-primary-200"
      },
      success: {
        bg: "bg-success-50",
        icon: "text-success",
        border: "border-success-200"
      },
      accent: {
        bg: "bg-accent-50",
        icon: "text-accent",
        border: "border-accent-200"
      }
    };
    return colorMap[color] || colorMap.primary;
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {metricsData.map((metric) => {
        const colors = getColorClasses(metric.color);
        
        return (
          <div key={metric.id} className="bg-surface rounded-lg border border-border p-6 shadow-card hover:shadow-modal transition-smooth">
            <div className="flex items-center justify-between mb-4">
              <div className={`w-12 h-12 ${colors.bg} rounded-lg flex items-center justify-center`}>
                <Icon name={metric.icon} size={24} className={colors.icon} />
              </div>
              <div className={`flex items-center space-x-1 text-sm font-medium ${
                metric.changeType === 'increase' ? 'text-success' : 'text-error'
              }`}>
                <Icon 
                  name={metric.changeType === 'increase' ? 'TrendingUp' : 'TrendingDown'} 
                  size={16} 
                />
                <span>{metric.change}</span>
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="text-text-secondary text-sm font-medium">{metric.title}</h3>
              <p className="text-2xl font-heading font-bold text-text-primary">{metric.value}</p>
              {metric.period && (
                <p className="text-xs text-text-secondary">{metric.period}</p>
              )}
            </div>

            {metric.breakdown && (
              <div className="mt-4 pt-4 border-t border-border">
                <div className="grid grid-cols-2 gap-2">
                  {metric.breakdown.map((item, index) => (
                    <div key={index} className="flex justify-between text-xs">
                      <span className="text-text-secondary">{item.label}</span>
                      <span className="font-medium text-text-primary">{item.count}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default MetricsOverview;