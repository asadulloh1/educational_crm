import React from 'react';
import Icon from 'components/AppIcon';

const RecentActivity = () => {
  const activityData = [
    {
      id: 1,
      type: "user_login",
      user: "Michael Rodriguez",
      role: "teacher",
      action: "logged in",
      timestamp: new Date(Date.now() - 300000), // 5 minutes ago
      details: "From IP: 192.168.1.45",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face"
    },
    {
      id: 2,
      type: "role_change",
      user: "Sarah Chen",
      role: "admin",
      action: "changed role",
      timestamp: new Date(Date.now() - 900000), // 15 minutes ago
      details: "Student → Parent for Emma Chen",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face"
    },
    {
      id: 3,
      type: "user_registration",
      user: "David Thompson",
      role: "parent",
      action: "registered",
      timestamp: new Date(Date.now() - 1800000), // 30 minutes ago
      details: "Pending email verification",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face"
    },
    {
      id: 4,
      type: "system_alert",
      user: "System",
      role: "system",
      action: "generated alert",
      timestamp: new Date(Date.now() - 2700000), // 45 minutes ago
      details: "High server load detected",
      avatar: null
    },
    {
      id: 5,
      type: "user_logout",
      user: "Jennifer Wilson",
      role: "teacher",
      action: "logged out",
      timestamp: new Date(Date.now() - 3600000), // 1 hour ago
      details: "Session duration: 3h 24m",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face"
    },
    {
      id: 6,
      type: "bulk_import",
      user: "Admin System",
      role: "admin",
      action: "imported users",
      timestamp: new Date(Date.now() - 5400000), // 1.5 hours ago
      details: "45 student records imported",
      avatar: null
    },
    {
      id: 7,
      type: "user_login",
      user: "Robert Martinez",
      role: "student",
      action: "logged in",
      timestamp: new Date(Date.now() - 7200000), // 2 hours ago
      details: "Mobile app login",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face"
    },
    {
      id: 8,
      type: "account_verification",
      user: "Lisa Anderson",
      role: "parent",
      action: "verified email",
      timestamp: new Date(Date.now() - 9000000), // 2.5 hours ago
      details: "Account activation complete",
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&h=150&fit=crop&crop=face"
    }
  ];

  const getActivityIcon = (type) => {
    const iconMap = {
      user_login: "LogIn",
      user_logout: "LogOut",
      user_registration: "UserPlus",
      role_change: "UserCog",
      system_alert: "AlertTriangle",
      bulk_import: "Upload",
      account_verification: "CheckCircle"
    };
    return iconMap[type] || "Activity";
  };

  const getActivityColor = (type) => {
    const colorMap = {
      user_login: "text-success",
      user_logout: "text-text-secondary",
      user_registration: "text-primary",
      role_change: "text-accent",
      system_alert: "text-error",
      bulk_import: "text-primary",
      account_verification: "text-success"
    };
    return colorMap[type] || "text-text-secondary";
  };

  const getRoleBadgeColor = (role) => {
    const colorMap = {
      admin: "bg-error-100 text-error-700",
      teacher: "bg-primary-100 text-primary-700",
      student: "bg-success-100 text-success-700",
      parent: "bg-accent-100 text-accent-700",
      system: "bg-secondary-100 text-secondary-700"
    };
    return colorMap[role] || "bg-secondary-100 text-secondary-700";
  };

  const formatTimeAgo = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return 'Just now';
  };

  return (
    <div className="p-4 space-y-4">
      {activityData.map((activity) => (
        <div key={activity.id} className="flex items-start space-x-3 p-3 hover:bg-secondary-50 rounded-lg transition-micro">
          <div className="flex-shrink-0">
            {activity.avatar ? (
              <img
                src={activity.avatar}
                alt={activity.user}
                className="w-8 h-8 rounded-full object-cover"
                onError={(e) => {
                  e.target.src = "/assets/images/no_image.png";
                }}
              />
            ) : (
              <div className="w-8 h-8 bg-secondary-100 rounded-full flex items-center justify-center">
                <Icon 
                  name={getActivityIcon(activity.type)} 
                  size={16} 
                  className={getActivityColor(activity.type)}
                />
              </div>
            )}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center space-x-2 mb-1">
              <p className="text-sm font-medium text-text-primary truncate">
                {activity.user}
              </p>
              <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getRoleBadgeColor(activity.role)}`}>
                {activity.role}
              </span>
            </div>
            
            <p className="text-sm text-text-secondary mb-1">
              {activity.action}
            </p>
            
            {activity.details && (
              <p className="text-xs text-text-secondary mb-2">
                {activity.details}
              </p>
            )}
            
            <div className="flex items-center space-x-2 text-xs text-text-secondary">
              <Icon name="Clock" size={12} />
              <span>{formatTimeAgo(activity.timestamp)}</span>
            </div>
          </div>

          <div className="flex-shrink-0">
            <Icon 
              name={getActivityIcon(activity.type)} 
              size={16} 
              className={getActivityColor(activity.type)}
            />
          </div>
        </div>
      ))}

      <div className="pt-4 border-t border-border">
        <div className="text-center">
          <p className="text-xs text-text-secondary mb-2">
            Showing recent 8 activities
          </p>
          <button className="text-xs text-primary hover:text-primary-700 font-medium transition-micro">
            Load More Activities
          </button>
        </div>
      </div>
    </div>
  );
};

export default RecentActivity;