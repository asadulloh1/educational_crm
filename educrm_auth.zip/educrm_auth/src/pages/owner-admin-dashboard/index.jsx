import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import RoleBasedHeader from 'components/ui/RoleBasedHeader';
import DashboardSidebar from 'components/ui/DashboardSidebar';
import Icon from 'components/AppIcon';
import MetricsOverview from './components/MetricsOverview';
import PriorityActions from './components/PriorityActions';
import InteractiveCalendar from './components/InteractiveCalendar';
import AnalyticsCharts from './components/AnalyticsCharts';
import QuickActions from './components/QuickActions';

const OwnerAdminDashboard = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isRightPanelOpen, setIsRightPanelOpen] = useState(true);
  const [isCalendarFullScreen, setIsCalendarFullScreen] = useState(false);
  const [refreshTime, setRefreshTime] = useState(new Date());
  const navigate = useNavigate();

  // Auto-refresh dashboard every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setRefreshTime(new Date());
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const handleToggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const handleToggleRightPanel = () => {
    setIsRightPanelOpen(!isRightPanelOpen);
  };

  const handleToggleCalendarFullScreen = () => {
    setIsCalendarFullScreen(!isCalendarFullScreen);
  };

  const mockUserData = {
    name: "Dr. Sarah Johnson",
    email: "sarah.johnson@educrm.com",
    role: "owner-admin"
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <RoleBasedHeader 
        userRole="owner-admin" 
        userName={mockUserData.name}
        userEmail={mockUserData.email}
      />

      {/* Hamburger Menu Button - Top Left */}
      <button
        onClick={handleToggleSidebar}
        className="fixed top-4 left-4 z-50 lg:hidden p-2 bg-surface border border-border rounded-lg shadow-sm text-text-secondary hover:text-primary hover:bg-secondary-50 transition-all duration-200"
      >
        <Icon name="Menu" size={20} />
      </button>

      {/* Sidebar */}
      <DashboardSidebar 
        userRole="owner-admin"
        isCollapsed={isSidebarCollapsed}
        onToggleCollapse={handleToggleSidebar}
      />

      {/* Main Content */}
      <div className={`transition-all duration-300 ease-in-out ${isSidebarCollapsed ? 'lg:pl-16' : 'lg:pl-72'}`}>
        <div className="pt-16">
          <div className="flex">
            {/* Main Dashboard Area */}
            <div className={`flex-1 transition-all duration-300 ease-in-out ${
              isRightPanelOpen && !isCalendarFullScreen ? 'lg:pr-80' : ''
            } ${isCalendarFullScreen ? 'lg:pr-96' : ''}`}>
              <div className={`p-6 space-y-6 transition-all duration-300 ${isCalendarFullScreen ? 'transform scale-95' : ''}`}>
                {/* Dashboard Header */}
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <h1 className="text-2xl font-heading font-bold text-text-primary">
                      Administrator Dashboard
                    </h1>
                    <p className="text-text-secondary mt-1">
                      Welcome back, {mockUserData.name.split(' ')[0]}. Here's your institutional overview.
                    </p>
                  </div>
                  <div className="flex items-center space-x-4 mt-4 sm:mt-0">
                    <div className="flex items-center space-x-2 text-sm text-text-secondary">
                      <Icon name="Clock" size={16} />
                      <span>Last updated: {refreshTime.toLocaleTimeString()}</span>
                    </div>
                    <button
                      onClick={handleToggleRightPanel}
                      className="lg:hidden p-2 text-text-secondary hover:text-primary hover:bg-secondary-50 rounded-lg transition-micro"
                    >
                      <Icon name="PanelRightOpen" size={20} />
                    </button>
                  </div>
                </div>

                {/* Metrics Overview */}
                <div className={isCalendarFullScreen ? 'w-3/5' : ''}>
                  <MetricsOverview />
                </div>

                {/* Priority Actions */}
                <div className={isCalendarFullScreen ? 'w-3/5' : ''}>
                  <PriorityActions />
                </div>

                {/* Analytics Charts */}
                <div className={isCalendarFullScreen ? 'w-3/5' : ''}>
                  <AnalyticsCharts />
                </div>

                {/* Quick Actions */}
                <div className={isCalendarFullScreen ? 'w-3/5' : ''}>
                  <QuickActions />
                </div>
              </div>
            </div>

            {/* Right Panel - Interactive Calendar */}
            <div className={`fixed right-0 top-16 h-full bg-surface border-l border-border transform transition-all duration-300 ease-in-out z-50 ${
              isCalendarFullScreen ? 'w-96 translate-x-0' : (
                isRightPanelOpen ? 'w-80 translate-x-0' : 'w-80 translate-x-full'
              )
            } lg:relative lg:top-0 lg:transform-none lg:z-auto`}>
              <div className="h-full flex flex-col">
                {/* Right Panel Header */}
                <div className="flex items-center justify-between p-4 border-b border-border">
                  <h3 className="font-heading font-semibold text-text-primary">Calendar & Events</h3>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={handleToggleCalendarFullScreen}
                      className="p-1.5 text-text-secondary hover:text-primary hover:bg-secondary-50 rounded-lg transition-micro"
                      title={isCalendarFullScreen ? "Exit Full Screen" : "Full Screen"}
                    >
                      <Icon name={isCalendarFullScreen ? "Minimize2" : "Maximize2"} size={16} />
                    </button>
                    <button
                      onClick={handleToggleRightPanel}
                      className="p-1.5 text-text-secondary hover:text-primary hover:bg-secondary-50 rounded-lg transition-micro"
                    >
                      <Icon name="X" size={16} />
                    </button>
                  </div>
                </div>

                {/* Interactive Calendar */}
                <div className="flex-1 overflow-hidden">
                  <InteractiveCalendar 
                    isFullScreen={isCalendarFullScreen}
                    onToggleFullScreen={handleToggleCalendarFullScreen}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Full Screen Calendar Backdrop */}
      {isCalendarFullScreen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-30 z-40 transition-opacity duration-300"
          onClick={handleToggleCalendarFullScreen}
        />
      )}

      {/* Mobile Right Panel Overlay */}
      {isRightPanelOpen && !isCalendarFullScreen && (
        <div 
          className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-40 transition-opacity duration-300"
          onClick={handleToggleRightPanel}
        />
      )}
    </div>
  );
};

export default OwnerAdminDashboard;