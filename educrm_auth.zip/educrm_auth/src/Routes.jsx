import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";

// Page imports
import LoginScreen from "pages/login-screen";
import UserRegistrationScreen from "pages/user-registration-screen";
import OwnerAdminDashboard from "pages/owner-admin-dashboard";
import TeacherDashboard from "pages/teacher-dashboard";
import StudentDashboard from "pages/student-dashboard";
import ParentDashboard from "pages/parent-dashboard";

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
        <ScrollToTop />
        <RouterRoutes>
          {/* Authentication Routes */}
          <Route path="/login-screen" element={<LoginScreen />} />
          <Route path="/user-registration-screen" element={<UserRegistrationScreen />} />
          
          {/* Dashboard Routes */}
          <Route path="/owner-admin-dashboard" element={<OwnerAdminDashboard />} />
          <Route path="/teacher-dashboard" element={<TeacherDashboard />} />
          <Route path="/student-dashboard" element={<StudentDashboard />} />
          <Route path="/parent-dashboard" element={<ParentDashboard />} />
          
          {/* Default redirect to login */}
          <Route path="/" element={<LoginScreen />} />
          
          {/* 404 Not Found - Fallback route */}
          <Route path="*" element={<LoginScreen />} />
        </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;