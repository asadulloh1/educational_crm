import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';

const MobileTabBar = ({ userRole }) => {
  const location = useLocation();
  const navigate = useNavigate();

  const getTabItems = (role) => {
    switch (role) {
      case 'student':
        return [
          {
            key: 'dashboard',
            label: 'Home',
            icon: 'Home',
            path: '/student-dashboard',
            badge: null
          },
          {
            key: 'assignments',
            label: 'Tasks',
            icon: 'FileText',
            path: '/student/assignments',
            badge: 3
          },
          {
            key: 'grades',
            label: 'Grades',
            icon: 'Award',
            path: '/student/grades',
            badge: null
          },
          {
            key: 'schedule',
            label: 'Schedule',
            icon: 'Calendar',
            path: '/student/schedule',
            badge: null
          },
          {
            key: 'profile',
            label: 'Profile',
            icon: 'User',
            path: '/student/profile',
            badge: null
          }
        ];

      case 'parent':
        return [
          {
            key: 'dashboard',
            label: 'Home',
            icon: 'Home',
            path: '/parent-dashboard',
            badge: null
          },
          {
            key: 'progress',
            label: 'Progress',
            icon: 'TrendingUp',
            path: '/parent/progress',
            badge: null
          },
          {
            key: 'messages',
            label: 'Messages',
            icon: 'MessageSquare',
            path: '/parent/messages',
            badge: 2
          },
          {
            key: 'events',
            label: 'Events',
            icon: 'Calendar',
            path: '/parent/events',
            badge: 1
          },
          {
            key: 'settings',
            label: 'Settings',
            icon: 'Settings',
            path: '/parent/settings',
            badge: null
          }
        ];

      default:
        return [];
    }
  };

  const tabItems = getTabItems(userRole);

  const handleTabClick = (path) => {
    navigate(path);
  };

  const isActive = (path) => {
    return location.pathname === path;
  };

  // Only show for student and parent roles on mobile
  if (!['student', 'parent'].includes(userRole)) {
    return null;
  }

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 z-1000">
      <div className="bg-surface border-t border-border">
        <div className="flex items-center justify-around px-2 py-2">
          {tabItems.map((tab) => (
            <button
              key={tab.key}
              onClick={() => handleTabClick(tab.path)}
              className={`flex flex-col items-center justify-center px-3 py-2 min-w-0 flex-1 relative transition-micro ${
                isActive(tab.path)
                  ? 'text-primary' :'text-text-secondary hover:text-text-primary'
              }`}
            >
              <div className="relative">
                <Icon 
                  name={tab.icon} 
                  size={20} 
                  className={isActive(tab.path) ? 'text-primary' : 'text-text-secondary'} 
                />
                {tab.badge && (
                  <span className="absolute -top-2 -right-2 bg-accent text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-medium">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className={`text-xs font-medium mt-1 truncate ${
                isActive(tab.path) ? 'text-primary' : 'text-text-secondary'
              }`}>
                {tab.label}
              </span>
              {isActive(tab.path) && (
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-8 h-0.5 bg-primary rounded-full"></div>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MobileTabBar;