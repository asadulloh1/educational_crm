import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';

const DashboardSidebar = ({ userRole, isCollapsed = false, onToggleCollapse }) => {
  const [expandedSections, setExpandedSections] = useState({});
  const location = useLocation();
  const navigate = useNavigate();

  const toggleSection = (sectionKey) => {
    setExpandedSections(prev => ({
      ...prev,
      [sectionKey]: !prev[sectionKey]
    }));
  };

  const getMenuItems = (role) => {
    switch (role) {
      case 'owner-admin':
        return [
          {
            key: 'dashboard',
            label: 'Dashboard',
            icon: 'LayoutDashboard',
            path: '/owner-admin-dashboard',
            active: location.pathname === '/owner-admin-dashboard'
          },
          {
            key: 'users',
            label: 'User Management',
            icon: 'Users',
            expandable: true,
            children: [
              { label: 'All Users', path: '/users', icon: 'UserCheck' },
              { label: 'Teachers', path: '/teachers', icon: 'GraduationCap' },
              { label: 'Students', path: '/students', icon: 'BookOpen' },
              { label: 'Parents', path: '/parents', icon: 'Heart' },
              { label: 'Add User', path: '/users/add', icon: 'UserPlus' }
            ]
          },
          {
            key: 'academics',
            label: 'Academic Management',
            icon: 'BookOpen',
            expandable: true,
            children: [
              { label: 'Courses', path: '/courses', icon: 'Book' },
              { label: 'Classes', path: '/classes', icon: 'Users' },
              { label: 'Subjects', path: '/subjects', icon: 'FileText' },
              { label: 'Curriculum', path: '/curriculum', icon: 'Layers' }
            ]
          },
          {
            key: 'analytics',
            label: 'Analytics & Reports',
            icon: 'BarChart3',
            expandable: true,
            children: [
              { label: 'Performance Analytics', path: '/analytics/performance', icon: 'TrendingUp' },
              { label: 'Usage Reports', path: '/analytics/usage', icon: 'Activity' },
              { label: 'Financial Reports', path: '/analytics/financial', icon: 'DollarSign' },
              { label: 'Custom Reports', path: '/analytics/custom', icon: 'FileBarChart' }
            ]
          },
          {
            key: 'system',
            label: 'System Settings',
            icon: 'Settings',
            expandable: true,
            children: [
              { label: 'General Settings', path: '/settings/general', icon: 'Sliders' },
              { label: 'Security', path: '/settings/security', icon: 'Shield' },
              { label: 'Integrations', path: '/settings/integrations', icon: 'Plug' },
              { label: 'Backup & Recovery', path: '/settings/backup', icon: 'Database' }
            ]
          },
          {
            key: 'communication',
            label: 'Communication',
            icon: 'MessageSquare',
            expandable: true,
            children: [
              { label: 'Announcements', path: '/communication/announcements', icon: 'Megaphone' },
              { label: 'Messages', path: '/communication/messages', icon: 'Mail' },
              { label: 'Notifications', path: '/communication/notifications', icon: 'Bell' }
            ]
          }
        ];

      case 'teacher':
        return [
          {
            key: 'dashboard',
            label: 'Dashboard',
            icon: 'LayoutDashboard',
            path: '/teacher-dashboard',
            active: location.pathname === '/teacher-dashboard'
          },
          {
            key: 'classes',
            label: 'My Classes',
            icon: 'Users',
            expandable: true,
            children: [
              { label: 'All Classes', path: '/classes', icon: 'Users' },
              { label: 'Class Schedule', path: '/classes/schedule', icon: 'Calendar' },
              { label: 'Attendance', path: '/classes/attendance', icon: 'CheckSquare' },
              { label: 'Class Materials', path: '/classes/materials', icon: 'FolderOpen' }
            ]
          },
          {
            key: 'assignments',
            label: 'Assignments',
            icon: 'FileText',
            expandable: true,
            children: [
              { label: 'Create Assignment', path: '/assignments/create', icon: 'FilePlus' },
              { label: 'All Assignments', path: '/assignments', icon: 'FileText' },
              { label: 'Submissions', path: '/assignments/submissions', icon: 'Upload' },
              { label: 'Grading', path: '/assignments/grading', icon: 'Award' }
            ]
          },
          {
            key: 'gradebook',
            label: 'Gradebook',
            icon: 'Award',
            expandable: true,
            children: [
              { label: 'Grade Entry', path: '/gradebook/entry', icon: 'Edit3' },
              { label: 'Grade Reports', path: '/gradebook/reports', icon: 'FileBarChart' },
              { label: 'Progress Tracking', path: '/gradebook/progress', icon: 'TrendingUp' }
            ]
          },
          {
            key: 'communication',
            label: 'Communication',
            icon: 'MessageSquare',
            expandable: true,
            children: [
              { label: 'Messages', path: '/messages', icon: 'Mail' },
              { label: 'Parent Communication', path: '/communication/parents', icon: 'Users' },
              { label: 'Announcements', path: '/communication/announcements', icon: 'Megaphone' }
            ]
          },
          {
            key: 'resources',
            label: 'Resources',
            icon: 'FolderOpen',
            expandable: true,
            children: [
              { label: 'Lesson Plans', path: '/resources/lessons', icon: 'BookOpen' },
              { label: 'Teaching Materials', path: '/resources/materials', icon: 'FileText' },
              { label: 'Media Library', path: '/resources/media', icon: 'Image' }
            ]
          }
        ];

      default:
        return [];
    }
  };

  const menuItems = getMenuItems(userRole);

  const handleNavigation = (path) => {
    if (path) {
      navigate(path);
    }
  };

  if (!['owner-admin', 'teacher'].includes(userRole)) {
    return null;
  }

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className={`hidden lg:fixed lg:inset-y-0 lg:flex lg:flex-col ${isCollapsed ? 'lg:w-16' : 'lg:w-72'} bg-surface border-r border-border z-1000 transition-all duration-300 ease-in-out`}>
        <div className="flex flex-col flex-1 min-h-0 pt-16">
          {/* Sidebar Header */}
          <div className="flex items-center justify-between px-4 py-4 border-b border-border">
            {!isCollapsed && (
              <h2 className="text-lg font-heading font-semibold text-text-primary leading-tight">
                {userRole === 'owner-admin' ? (
                  <span className="break-words">Administrator Portal</span>
                ) : (
                  'Teacher Hub'
                )}
              </h2>
            )}
            <button
              onClick={onToggleCollapse}
              className="p-1.5 text-text-secondary hover:text-primary hover:bg-secondary-50 rounded-lg transition-all duration-200 flex-shrink-0"
              title={isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
            >
              <Icon name={isCollapsed ? "ChevronRight" : "ChevronLeft"} size={16} />
            </button>
          </div>

          {/* Navigation Menu */}
          <nav className="flex-1 px-4 py-4 space-y-2 overflow-y-auto">
            {menuItems.map((item) => (
              <div key={item.key}>
                {item.expandable ? (
                  <div>
                    <button
                      onClick={() => !isCollapsed && toggleSection(item.key)}
                      className={`w-full flex items-center justify-between px-3 py-2 text-sm font-medium rounded-lg transition-all duration-200 ${
                        expandedSections[item.key] && !isCollapsed
                          ? 'bg-primary-50 text-primary font-bold' : 'text-text-secondary hover:text-text-primary hover:bg-secondary-50'
                      } ${location.pathname.startsWith(item.children?.[0]?.path?.split('/')[1] ? `/${item.children[0].path.split('/')[1]}` : '') ? 'font-bold text-primary' : ''}`}
                      title={isCollapsed ? item.label : ''}
                    >
                      <div className="flex items-center space-x-3">
                        <Icon name={item.icon} size={18} />
                        {!isCollapsed && <span>{item.label}</span>}
                      </div>
                      {!isCollapsed && (
                        <Icon
                          name="ChevronDown"
                          size={16}
                          className={`transition-transform duration-200 ${expandedSections[item.key] ? 'rotate-180' : ''}`}
                        />
                      )}
                    </button>
                    
                    {expandedSections[item.key] && !isCollapsed && (
                      <div className="mt-2 ml-6 space-y-1 animate-in slide-in-from-top-2 duration-200">
                        {item.children.map((child, index) => (
                          <button
                            key={index}
                            onClick={() => handleNavigation(child.path)}
                            className={`w-full flex items-center space-x-3 px-3 py-2 text-sm rounded-lg transition-all duration-200 ${
                              location.pathname === child.path
                                ? 'bg-primary text-white font-bold' : 'text-text-secondary hover:text-text-primary hover:bg-secondary-50'
                            }`}
                          >
                            <Icon name={child.icon} size={16} />
                            <span>{child.label}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <button
                    onClick={() => handleNavigation(item.path)}
                    className={`w-full flex items-center space-x-3 px-3 py-2 text-sm font-medium rounded-lg transition-all duration-200 ${
                      item.active
                        ? 'bg-primary text-white font-bold' : 'text-text-secondary hover:text-text-primary hover:bg-secondary-50'
                    }`}
                    title={isCollapsed ? item.label : ''}
                  >
                    <Icon name={item.icon} size={18} />
                    {!isCollapsed && <span>{item.label}</span>}
                  </button>
                )}
              </div>
            ))}
          </nav>

          {/* Sidebar Footer */}
          {!isCollapsed && (
            <div className="p-4 border-t border-border">
              <div className="bg-accent-50 rounded-lg p-3">
                <div className="flex items-center space-x-2 mb-2">
                  <Icon name="Lightbulb" size={16} className="text-accent" />
                  <span className="text-sm font-medium text-accent-700">Quick Tip</span>
                </div>
                <p className="text-xs text-accent-600">
                  Use keyboard shortcuts to navigate faster. Press '?' for help.
                </p>
              </div>
            </div>
          )}
        </div>
      </aside>

      {/* Mobile Sidebar Overlay */}
      <div className="lg:hidden">
        {/* This would be implemented as a drawer/modal for mobile */}
      </div>
    </>
  );
};

export default DashboardSidebar;