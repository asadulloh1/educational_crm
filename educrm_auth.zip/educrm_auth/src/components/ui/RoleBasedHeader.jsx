import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';

const RoleBasedHeader = ({ userRole, userName = "User", userEmail = "user@example.com" }) => {
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const isAuthPage = location.pathname === '/login-screen' || location.pathname === '/user-registration-screen';

  const getRoleDisplayName = (role) => {
    const roleMap = {
      'owner-admin': 'Administrator',
      'teacher': 'Teacher',
      'student': 'Student',
      'parent': 'Parent'
    };
    return roleMap[role] || 'User';
  };

  const getRoleQuickActions = (role) => {
    switch (role) {
      case 'owner-admin':
        return [
          { label: 'User Management', icon: 'Users', action: () => console.log('User Management') },
          { label: 'System Settings', icon: 'Settings', action: () => console.log('System Settings') },
          { label: 'Analytics', icon: 'BarChart3', action: () => console.log('Analytics') }
        ];
      case 'teacher':
        return [
          { label: 'My Classes', icon: 'BookOpen', action: () => console.log('My Classes') },
          { label: 'Gradebook', icon: 'FileText', action: () => console.log('Gradebook') },
          { label: 'Messages', icon: 'MessageSquare', action: () => console.log('Messages') }
        ];
      case 'student':
        return [
          { label: 'Assignments', icon: 'FileText', action: () => console.log('Assignments') },
          { label: 'Grades', icon: 'Award', action: () => console.log('Grades') },
          { label: 'Schedule', icon: 'Calendar', action: () => console.log('Schedule') }
        ];
      case 'parent':
        return [
          { label: 'Child Progress', icon: 'TrendingUp', action: () => console.log('Child Progress') },
          { label: 'Messages', icon: 'MessageSquare', action: () => console.log('Messages') },
          { label: 'Events', icon: 'Calendar', action: () => console.log('Events') }
        ];
      default:
        return [];
    }
  };

  const handleLogout = () => {
    navigate('/login-screen');
    setIsProfileOpen(false);
  };

  const handleProfileClick = () => {
    setIsProfileOpen(!isProfileOpen);
  };

  const handleMobileMenuToggle = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  if (isAuthPage) {
    return (
      <header className="bg-surface border-b border-border fixed top-0 left-0 right-0 z-1000">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0 cursor-pointer" onClick={() => navigate('/login-screen')}>
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                    <Icon name="GraduationCap" size={20} color="white" />
                  </div>
                  <span className="text-xl font-heading font-semibold text-text-primary">EduCRM</span>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/login-screen')}
                className="text-text-secondary hover:text-primary transition-micro text-sm font-medium"
              >
                Sign In
              </button>
              <button
                onClick={() => navigate('/user-registration-screen')}
                className="bg-primary hover:bg-primary-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-micro"
              >
                Get Started
              </button>
            </div>
          </div>
        </div>
      </header>
    );
  }

  const quickActions = getRoleQuickActions(userRole);

  return (
    <header className="bg-surface border-b border-border fixed top-0 left-0 right-0 z-1000">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 cursor-pointer" onClick={() => navigate(`/${userRole}-dashboard`)}>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <Icon name="GraduationCap" size={20} color="white" />
                </div>
                <span className="text-xl font-heading font-semibold text-text-primary">EduCRM</span>
              </div>
            </div>
            <div className="hidden md:block ml-8">
              <span className="text-sm text-text-secondary font-medium">
                {getRoleDisplayName(userRole)} Portal
              </span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-4">
            {/* Quick Actions */}
            <div className="flex items-center space-x-2">
              {quickActions.slice(0, 3).map((action, index) => (
                <button
                  key={index}
                  onClick={action.action}
                  className="p-2 text-text-secondary hover:text-primary hover:bg-secondary-50 rounded-lg transition-micro"
                  title={action.label}
                >
                  <Icon name={action.icon} size={18} />
                </button>
              ))}
            </div>

            {/* Notifications */}
            <button className="p-2 text-text-secondary hover:text-primary hover:bg-secondary-50 rounded-lg transition-micro relative">
              <Icon name="Bell" size={18} />
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-accent rounded-full"></span>
            </button>

            {/* User Profile */}
            <div className="relative">
              <button
                onClick={handleProfileClick}
                className="flex items-center space-x-2 p-2 rounded-lg hover:bg-secondary-50 transition-micro"
              >
                <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center">
                  <span className="text-sm font-medium text-primary">
                    {userName.charAt(0).toUpperCase()}
                  </span>
                </div>
                <Icon name="ChevronDown" size={16} className="text-text-secondary" />
              </button>

              {isProfileOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-surface rounded-lg shadow-dropdown border border-border z-1010">
                  <div className="p-4 border-b border-border">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center">
                        <span className="text-lg font-medium text-primary">
                          {userName.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <div>
                        <p className="font-medium text-text-primary">{userName}</p>
                        <p className="text-sm text-text-secondary">{userEmail}</p>
                        <p className="text-xs text-accent font-medium">{getRoleDisplayName(userRole)}</p>
                      </div>
                    </div>
                  </div>
                  <div className="p-2">
                    <button className="w-full text-left px-3 py-2 text-sm text-text-primary hover:bg-secondary-50 rounded-lg transition-micro flex items-center space-x-2">
                      <Icon name="User" size={16} />
                      <span>Profile Settings</span>
                    </button>
                    <button className="w-full text-left px-3 py-2 text-sm text-text-primary hover:bg-secondary-50 rounded-lg transition-micro flex items-center space-x-2">
                      <Icon name="Settings" size={16} />
                      <span>Preferences</span>
                    </button>
                    <button className="w-full text-left px-3 py-2 text-sm text-text-primary hover:bg-secondary-50 rounded-lg transition-micro flex items-center space-x-2">
                      <Icon name="HelpCircle" size={16} />
                      <span>Help & Support</span>
                    </button>
                    <hr className="my-2 border-border" />
                    <button
                      onClick={handleLogout}
                      className="w-full text-left px-3 py-2 text-sm text-error hover:bg-error-50 rounded-lg transition-micro flex items-center space-x-2"
                    >
                      <Icon name="LogOut" size={16} />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={handleMobileMenuToggle}
              className="p-2 text-text-secondary hover:text-primary hover:bg-secondary-50 rounded-lg transition-micro"
            >
              <Icon name={isMobileMenuOpen ? "X" : "Menu"} size={20} />
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden border-t border-border bg-surface">
            <div className="p-4 space-y-4">
              <div className="flex items-center space-x-3 pb-4 border-b border-border">
                <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center">
                  <span className="text-lg font-medium text-primary">
                    {userName.charAt(0).toUpperCase()}
                  </span>
                </div>
                <div>
                  <p className="font-medium text-text-primary">{userName}</p>
                  <p className="text-sm text-text-secondary">{getRoleDisplayName(userRole)}</p>
                </div>
              </div>
              
              <div className="space-y-2">
                {quickActions.map((action, index) => (
                  <button
                    key={index}
                    onClick={action.action}
                    className="w-full text-left px-3 py-2 text-sm text-text-primary hover:bg-secondary-50 rounded-lg transition-micro flex items-center space-x-3"
                  >
                    <Icon name={action.icon} size={18} />
                    <span>{action.label}</span>
                  </button>
                ))}
                
                <button className="w-full text-left px-3 py-2 text-sm text-text-primary hover:bg-secondary-50 rounded-lg transition-micro flex items-center space-x-3">
                  <Icon name="Bell" size={18} />
                  <span>Notifications</span>
                  <span className="ml-auto w-2 h-2 bg-accent rounded-full"></span>
                </button>
                
                <button className="w-full text-left px-3 py-2 text-sm text-text-primary hover:bg-secondary-50 rounded-lg transition-micro flex items-center space-x-3">
                  <Icon name="Settings" size={18} />
                  <span>Settings</span>
                </button>
                
                <button
                  onClick={handleLogout}
                  className="w-full text-left px-3 py-2 text-sm text-error hover:bg-error-50 rounded-lg transition-micro flex items-center space-x-3"
                >
                  <Icon name="LogOut" size={18} />
                  <span>Sign Out</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default RoleBasedHeader;