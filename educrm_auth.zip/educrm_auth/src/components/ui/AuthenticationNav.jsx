import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';

const AuthenticationNav = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const isLoginPage = location.pathname === '/login-screen';
  const isRegistrationPage = location.pathname === '/user-registration-screen';

  const handleLogoClick = () => {
    navigate('/login-screen');
  };

  const handleToggleAuth = () => {
    if (isLoginPage) {
      navigate('/user-registration-screen');
    } else {
      navigate('/login-screen');
    }
  };

  return (
    <header className="bg-surface border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <div className="flex-shrink-0 cursor-pointer" onClick={handleLogoClick}>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <Icon name="GraduationCap" size={20} color="white" />
                </div>
                <span className="text-xl font-heading font-semibold text-text-primary">EduCRM</span>
              </div>
            </div>
          </div>

          {/* Navigation Links */}
          <div className="flex items-center space-x-6">
            {/* Help & Support */}
            <button className="flex items-center space-x-2 text-text-secondary hover:text-primary transition-micro">
              <Icon name="HelpCircle" size={18} />
              <span className="hidden sm:inline text-sm font-medium">Help</span>
            </button>

            {/* Authentication Toggle */}
            <div className="flex items-center space-x-4">
              {isLoginPage ? (
                <>
                  <span className="text-sm text-text-secondary">New to EduCRM?</span>
                  <button
                    onClick={handleToggleAuth}
                    className="bg-primary hover:bg-primary-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-micro flex items-center space-x-2"
                  >
                    <Icon name="UserPlus" size={16} />
                    <span>Create Account</span>
                  </button>
                </>
              ) : (
                <>
                  <span className="text-sm text-text-secondary">Already have an account?</span>
                  <button
                    onClick={handleToggleAuth}
                    className="text-primary hover:text-primary-700 px-4 py-2 text-sm font-medium transition-micro flex items-center space-x-2"
                  >
                    <Icon name="LogIn" size={16} />
                    <span>Sign In</span>
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Progress Indicator */}
      <div className="bg-secondary-50 border-t border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center py-3">
            <div className="flex items-center space-x-4">
              <div className={`flex items-center space-x-2 ${isLoginPage ? 'text-primary' : 'text-text-secondary'}`}>
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium ${
                  isLoginPage ? 'bg-primary text-white' : 'bg-secondary-200 text-text-secondary'
                }`}>
                  1
                </div>
                <span className="text-sm font-medium">Sign In</span>
              </div>
              
              <div className="w-8 h-px bg-secondary-200"></div>
              
              <div className={`flex items-center space-x-2 ${isRegistrationPage ? 'text-primary' : 'text-text-secondary'}`}>
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium ${
                  isRegistrationPage ? 'bg-primary text-white' : 'bg-secondary-200 text-text-secondary'
                }`}>
                  2
                </div>
                <span className="text-sm font-medium">Get Started</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default AuthenticationNav;